#!/usr/bin/env python3
"""Black-box CLI canaries in disposable copied outputs; no acceptance imports."""
from hashlib import sha256
import json
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile

ROOT=Path(__file__).resolve().parents[1]

def run(args):
    p=subprocess.run([sys.executable,str(ROOT/'engineer/pilot.py')]+args,
                     capture_output=True,text=True,timeout=40)
    return {'returncode':p.returncode,'stderr':p.stderr[-1000:]}

def main():
    result={}
    with tempfile.TemporaryDirectory(prefix='cli_checks_',dir=ROOT/'referee') as temp:
        tmp=Path(temp)
        result['cuda_without_device']=run(['--backend','cuda','--out',str(tmp/'cuda')])
        result['cuda_without_device']['passed']=(result['cuda_without_device']['returncode']==2 and
            'no CPU fallback' in result['cuda_without_device']['stderr'] and not (tmp/'cuda').exists())
        source=tmp/'source';shutil.copytree(ROOT/'source',source)
        with (source/'FLOW.json').open('a') as f:f.write('\n')
        result['altered_source']=run(['--source',str(source),'--out',str(tmp/'wrongsource')])
        result['altered_source']['passed']=(result['altered_source']['returncode']==2 and
            'Source SHA256 mismatch: FLOW.json' in result['altered_source']['stderr'])
        out=tmp/'resume';shutil.copytree(ROOT/'engineer/run',out)
        base=['--out',str(out),'--count','4096','--chunk-size','256','--exact-limit','32','--seed','20260909',
              '--control',str(ROOT/'engineer/controls/WITNESS.json'),
              '--control',str(ROOT/'engineer/controls/NEAR_SINGULAR_CANARY.json'),'--resume']
        original=(out/'exact_candidates.json').read_bytes()
        result['clean_resume']=run(base)
        if result['clean_resume']['returncode']==0:
            report=json.loads((out/'RUN_REPORT.json').read_text())
            result['clean_resume']['resumed_chunks']=report['resumed_chunk_count']
            result['clean_resume']['exact_output_identical']=(out/'exact_candidates.json').read_bytes()==original
            result['clean_resume']['passed']=report['resumed_chunk_count']==16 and result['clean_resume']['exact_output_identical']
        else:result['clean_resume']['passed']=False
        cfg=out/'config.json';originalcfg=cfg.read_bytes();doc=json.loads(originalcfg);doc['seed']+=1;cfg.write_text(json.dumps(doc))
        result['changed_resume_configuration']=run(base)
        result['changed_resume_configuration']['passed']=(result['changed_resume_configuration']['returncode']==2 and
            'Resume configuration/code/source mismatch' in result['changed_resume_configuration']['stderr'])
        cfg.write_bytes(originalcfg)
        chunk=out/'chunk_00000.json';doc=json.loads(chunk.read_text());doc['payload']['unbound_mutation']=True
        chunk.write_text(json.dumps(doc))
        result['changed_resume_payload']=run(base)
        result['changed_resume_payload']['passed']=(result['changed_resume_payload']['returncode']==2 and
            'Resume chunk payload mismatch' in result['changed_resume_payload']['stderr'])
    result['all_passed']=all(v['passed'] for v in result.values())
    result['producer_sha256']=sha256((ROOT/'engineer/pilot.py').read_bytes()).hexdigest()
    result['gpu_execution']='UNTESTED: requested unavailable backend failed closed'
    (ROOT/'referee/OPERATIONAL_CHECKS.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))
    if not result['all_passed']:raise SystemExit(1)

if __name__=='__main__':main()
