# Actual-parent discovery and CUDA portability pilot

User instruction: "let's go with your plan and then also update github and google drive".
This explicitly authorizes the bounded computational pilot and publication of
its reviewed outputs to `reuellee/finite-certificates`, plus backups in
`Projects/research-backups`. No paid compute/APIs, secrets, unrelated files,
force pushes, repository settings changes, or destructive actions are authorized.
Use the GitHub connector. Only the coordinator publishes or changes status.

Mathematical source: PR49 head `59fec66666518257c585194b81061f60d91f439d`,
tree `9d3be78b6e8235af786c2ccb2ac24d977f12347a`. Publication base main is
`9e77c365b266e9d884e6ac14a0443992bec92c64`, tree
`abea1e32e8809e243c297b0107f195b2978b0d71`; PR49 remains open and untouched.
Source manifests and original NPZ are in `source/`. Prior accepted collision
diagnostic is `../collision_diagnostic/`; original map and ledger in
`../injectivity/`. All are read-only worker inputs.

## Scope and strategy

The preceding two diagnostics leave the theorem score2/9, seven original
obligations open, original injectivity open, original pair coverage UNKNOWN,
and original residual unchanged. This user-approved engineering/discovery
pilot does not claim a new theorem-converging continuation of the retired
abstract collision-deletion route. No theorem-distance decrease is promised.
The local PROTOCOL.md's prior GitHub-read-only epoch is superseded only for
this work by the quoted current publication instruction; historical protocol
files and theorem assertions are not rewritten.

Compare: repeating abstract collision deletion is retired because it loses
singleton Hc2; a full parent compactification proof lacks its global inputs;
a bounded actual-parent certificate search can test the GPU/CPU division of
work and retain actual geometry but has no global coverage consequence.
Select the last for this finite pilot. Stop after the stated batch and exact
certificate/review gates. It cannot justify another same-route theorem cycle.

1. Engineering/discovery worker owns `engineer/`: implement a deterministic
   actual-parent batch search, NumPy CPU path and optional CuPy CUDA path.
   Use original colex triples, all70 parent brackets, all56 derived normals,
   and the three original proper signatures in FLOW.json. Preserve exact
   rational candidate coordinates alongside any float arrays. Profile CPU
   stage costs. Generate exact primal or Gordan certificates for a bounded
   selected subset, with explicit UNKNOWN for failed reconstruction. Never
   turn approximate singularity or a solver failure into a proof. CUDA may
   not silently fall back to CPU or report unmeasured speedup. Include GPU
   synchronization in timing. No device is exposed in this environment.
   Include known event-side controls, but distinguish them from novel search.
   Budget: <=4096 generated parent candidates, <=32 selected parents for
   exact full block verification, <=25 minutes, <=4GiB temporary arrays.
   A simple CPU/optional-GPU CLI and resumable deterministic chunk output
   are sufficient. No expensive solver port or dependency installation on GPU.
2. Structural/falsifier worker owns `structural/`: bounded attempt to construct
   an exact positive THREE-row circuit in an actual strict row2599 parent,
   for one of the three fixed source signatures, using the exceptional
   localization types36,39,46,47. Start from all178 source charts and exact
   small rational wall solves as useful; do not replace source signatures
   by arbitrary signs. At most20 minutes, at most128 targeted wall solves.
   Record searched domain and exact admissibility failures for null outcomes.
   Any found witness is only a local certificate, never a global Hc claim.
3. Referee owns `referee/`: independently bind source NPZ chart0/signatures,
   audit opening scope and proposed numerical-to-exact boundary, then verify
   frozen candidates from literal parent matrices with separate determinant,
   rank and witness logic. Inspect CUDA branch statically, run CPU checks and
   meaningful hostile inputs. Do not import producer acceptance code. Label
   GPU execution untested. Verdict cannot promote the original theorem.

Coordinator owns source acquisition, integration, publication, backups, and
honest ledger/proof-distance accounting. Workers may not edit each other's
files or publish. No author/human contact. Every positive/null/timeout handoff
must be reproducible and useful; stop on the ceiling rather than expanding it.
