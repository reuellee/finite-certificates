#!/usr/bin/env python3
"""Engineering integration checks. Mathematical independence lives in referee/."""
from hashlib import sha256
import json
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile

HERE=Path(__file__).resolve().parent


def main():
    script=HERE/'pilot.py'
    controls=[str(x) for name in ['WITNESS.json','NEAR_SINGULAR_CANARY.json']
              for x in [HERE/'controls'/name]]
    flags=[item for x in controls for item in ['--control',x]]
    source=HERE.parent/'source'
    result={}
    with tempfile.TemporaryDirectory(prefix='9dvl-pilot-qa-') as tmp:
        tmp=Path(tmp)
        replay=tmp/'replay'
        shutil.copytree(HERE/'run',replay)
        command=[sys.executable,str(script),'--out',str(replay),'--source',str(source),*flags,'--resume']
        run=subprocess.run(command,text=True,capture_output=True,timeout=60)
        if run.returncode:
            raise RuntimeError(run.stderr)
        report=json.loads((replay/'RUN_REPORT.json').read_text())
        same=(replay/'exact_candidates.json').read_bytes()==(HERE/'run'/'exact_candidates.json').read_bytes()
        assert report['resumed_chunk_count']==16 and same
        result['complete_resume']={'passed':True,'resumed_chunks':16,'exact_artifact_byte_identical':same,
                                   'wall_seconds':report['wall_seconds_this_invocation']}
        p=replay/'chunk_00000.json'
        d=json.loads(p.read_text());d['payload']['records'][0]['id']=9999;p.write_text(json.dumps(d))
        run=subprocess.run(command,text=True,capture_output=True,timeout=60)
        assert run.returncode==2 and 'Resume chunk payload mismatch' in run.stderr
        result['tampered_chunk_rejected']={'passed':True,'exit_code':run.returncode,'stderr':run.stderr.strip()}
        d=json.loads((replay/'config.json').read_text());d['seed']+=1
        (replay/'config.json').write_text(json.dumps(d))
        run=subprocess.run(command,text=True,capture_output=True,timeout=60)
        assert run.returncode==2 and 'Resume configuration/code/source mismatch' in run.stderr
        result['configuration_mismatch_rejected']={'passed':True,'exit_code':run.returncode,'stderr':run.stderr.strip()}
        bad_source=tmp/'bad_source';bad_source.mkdir()
        for name in ['parent_bank.npz','FLOW.json','DISCOVERED_EVENT.json','EVENT_CERTIFICATE.json']:
            shutil.copy2(source/name,bad_source/name)
        p=bad_source/'FLOW.json';d=json.loads(p.read_text());d['signatures'][0]+=1;p.write_text(json.dumps(d))
        run=subprocess.run([sys.executable,str(script),'--source',str(bad_source),'--out',str(tmp/'bad_run')],
                           text=True,capture_output=True,timeout=60)
        assert run.returncode==2 and 'Source SHA256 mismatch: FLOW.json' in run.stderr
        result['modified_source_rejected']={'passed':True,'exit_code':run.returncode,'stderr':run.stderr.strip()}
        run=subprocess.run([sys.executable,str(script),'--backend','cuda','--out',str(tmp/'cuda_run')],
                           text=True,capture_output=True,timeout=60)
        assert run.returncode==2 and 'CUDA requested but unavailable; no CPU fallback' in run.stderr
        result['absent_cuda_no_silent_fallback']={'passed':True,'exit_code':run.returncode,'stderr':run.stderr.strip(),
                                               'cuda_branch_execution':'UNTESTED_NO_DEVICE_OR_CUPY'}
    result['producer_code_sha256']=sha256(script.read_bytes()).hexdigest()
    (HERE/'QA_REPORT.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
    print(json.dumps(result,indent=2))


if __name__=='__main__':
    main()
