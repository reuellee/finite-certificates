# Publication boundary

The current user explicitly authorized executing the proposed bounded pilot
and updating GitHub and Google Drive. Publish the accepted previous injectivity
attack, the accepted collision-deletion diagnostic, and this actual-parent
pilot as one self-contained follow-up under
`ops/research-team/experiments/2026-09-09-injectivity-cuda/`.

Use an additive branch from the recorded live main, with a dedicated pull
request, a README pointer, and a focused exact replay workflow. Preserve PR49
and the original canonical theorem ledger. Original source files in the
experiment are pinned evidence copies; no original proof input is rewritten.
The focused workflow uses `pull_request`, a read-only token, standard CPU
dependencies, and exact verifiers. No CUDA run is reported on CPU CI.
The new entrypoint is `replay_checkpoint.py`, registered in this dedicated
workflow. Existing `verify_*.py` discovery and its frozen historical verifier
census are unchanged; no existing verifier is excluded or modified.

Publish only after independent review and a clean local replay. Inspect the
created PR and its commit tree and report CI state honestly. A PR publication
is not a merge. Any later merge still requires the original applicable checks
and exact reviewed-head identity.

The recovery ZIP preserves all relative directories and contains a full
manifest. It is an evidence checkpoint, not a full repository-history backup.
Save the report and ZIP, then upload the ZIP only to the authorized
Google Drive `Projects/research-backups` folder and verify metadata.
