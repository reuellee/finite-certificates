#!/usr/bin/env python3
"""Extract a compact witness and construct an exact off-wall numerical canary."""
from pathlib import Path
from fractions import Fraction as Q
import json
import numpy as np
from search_three_circuit import det, normal, sign, BASES

HERE=Path(__file__).resolve().parent

def main():
 result=json.loads((HERE/'SEARCH_RESULT.json').read_text());ws=result['witnesses']
 if not ws: raise SystemExit('No witness available; the search is a bounded null.')
 w=min(ws,key=lambda x:sum(len(str(v)) for v in x['weights'])+len(x['delta']))
 y=[[Q(v) for v in row] for row in w['parent']]
 ctrl=[row[:] for row in y];coord,label=w['coordinate'];ctrl[coord][label]+=Q(1,10**12)
 ss=[]
 for idx,t in zip(w['support']['indices'],w['support']['triples']):
  ss.append([x*(1 if w['signature']>>idx&1 else -1) for x in normal(ctrl,t)])
 minor=det([[row[c] for c in w['wall_minor_columns']] for row in ss]);assert minor
 b=[det([[ctrl[k][j] for j in base] for k in range(4)]) for base in BASES]
 assert [sign(x) for x in b]==w['parent_signs']
 a=np.array(ss,dtype=float);a/=np.linalg.norm(a,axis=1)[:,None];sv=np.linalg.svd(a,compute_uv=False)
 control=dict(classification='EXACT_RANK_THREE_DESPITE_FLOAT_NEAR_SINGULARITY',parent=[[str(x) for x in row] for row in ctrl],signature=w['signature'],support_indices=w['support']['indices'],coordinate=[coord,label],offset_from_witness='1/1000000000000',parent_signs=[sign(x) for x in b],nonzero_rank_three_minor=str(minor),minor_columns=w['wall_minor_columns'],minimum_absolute_parent_bracket=str(min(abs(x) for x in b)),normalized_singular_values=sv.tolist(),singular_ratio=float(sv[-1]/sv[-2]),illustrative_float_rank_threshold=1e-10,approximate_rule_would_call_rank_two=bool(sv[-1]/sv[-2]<1e-10),exact_rank=3,acceptance='REJECT_AS_THREE_ROW_CIRCUIT',reason='A nonzero exact 3x3 minor excludes every dependence of these three rows; numerical smallness is not an equality certificate.')
 counts=dict(positive_certificates=len(ws),distinct_parent_matrices=len({tuple(tuple(row) for row in x['parent']) for x in ws}),distinct_parent_support_signature=len({(tuple(tuple(row) for row in x['parent']),tuple(x['support']['indices']),x['signature']) for x in ws}),distinct_supports=len({tuple(x['support']['indices']) for x in ws}),distinct_signatures=len({x['signature'] for x in ws}),distinct_source_charts=len({x['chart_index'] for x in ws}))
 for name,record in [('WITNESS.json',w),('NEAR_SINGULAR_CANARY.json',control),('DISTINCT_COUNTS.json',counts)]:
  (HERE/name).write_text(json.dumps(record,indent=2)+'\n')
 print(json.dumps(counts,sort_keys=True))

if __name__=='__main__':main()
