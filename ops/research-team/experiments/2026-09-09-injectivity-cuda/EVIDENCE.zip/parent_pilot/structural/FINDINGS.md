# Exact positive three-row circuits in an actual row2599 parent

Status: LOCAL CERTIFICATES ONLY. Original injectivity remains OPEN; theorem
ledger remains **2/9**. No original cohomology obligation is discharged.

## Bounded search and result

The search starts from the source bank's 178 literal integer parent matrices.
It screens 840 three-normal supports per chart: choose a common parent label,
one unused label, and a matching of the six remaining labels. Each support is
therefore three triples whose only common label is the center and whose other
labels are pairwise distinct. These are precisely relabelings of the
three-row portions of the source localization templates 36, 39, 46, and 47.
The four-row wall classification itself is inherited from the source checker;
this pilot does not recompute the orbit classification.

The numerical screening visits 149,520 unsigned matrices and 448,560
signature/support cases, using only the three original FLOW signatures. There
are 43,320 numerically aligned cases. Sorted normalized singular-value ratios
select 128 distinct chart/support cases, retaining their best-ranked aligned
source signature. No numerical observation is accepted as a certificate.

Exactly **128** targeted, exact, one-coordinate affine wall solves were run.
Changing a label belonging to only one of the three triples makes the wall
minor affine in that coordinate. The strongest coordinate derivative is
chosen; its unique rational root is substituted into the literal parent.
Every attempted wall has exact signed-normal rank two. All are checked against
all 70 strict original parent signs, and their three rational circuit weights
are recomputed from two-column minors.

- 101 solves give strictly positive exact circuit weights and retain all 70 signs.
- 27 solves fail at least one original parent sign and are rejected.
- The 101 accepted records have 101 distinct literal parent matrices, 10 distinct
  supports, two fixed source signatures, and 71 distinct seed charts.
- These counts describe local certificates, not new global cases, orbits, or
  components. The finite search gives no coverage of the continuous parent space.
- Source signature index 0 yielded no accepted certificate in this selected
  batch. This is not a nonexistence statement for that signature.

The recorded run took about 0.78 seconds, including about 0.52 seconds for
screening, on this session. Times are descriptive measurements and carry no
cross-machine or CUDA speedup claim.

## Compact exact witness

The chosen witness is attempt 65, derived from source chart 32 by replacing
zero-based entry `Y[2][0]` with `-13591/3472`, a change of `297/3472`.
The full matrix and all 70 sign checks are in `WITNESS.json`.

The source signature is `40418075143643136` (index 2). For the three original
colex normal indices `[35,24,17]`, corresponding to one-based parent triples
`128`, `247`, and `256`, the **signed raw cofactor normals** are

| Triple | Signed raw normal |
|---|---|
| 128 | (-8760/217, -1785/62, 360, -61605/217) |
| 247 | (238, 153, 124, 584) |
| 256 | (-113, -68, -682, 25) |

They satisfy the exact identity

\[
5642a_{128}+2595a_{247}+3450a_{256}=0.
\]

All three coefficients are strictly positive, and the three rows have exact
rank two. Therefore this fixed strict-feasibility block has a three-row Gordan
certificate of infeasibility at the stated parent. All parent brackets remain
strict with exactly the original signs. Source-signature properness is inherited
from the pinned original source and checked separately by the coordinator/referee;
no new signs were invented. Uniformity also excludes proportional distinct
normals: equal triple spans would place at least four parent columns in one
hyperplane.

This is a concrete reason that excluding proportional normals does **not**
justify excluding positive three-row circuits. It neither proves nor disproves
the original global injectivity assertion.

## Numerical canary

`NEAR_SINGULAR_CANARY.json` changes the same coordinate by another exact
`1/1000000000000`. All 70 original strict signs still hold. The same signed
three-normal matrix then has normalized singular-value ratio approximately
`9.16e-14`, so an illustrative threshold `sigma3/sigma2 < 1e-10` would call it
rank two. Its exact three-column minor, in zero-based columns `[1,2,3]`, is

\[
-8463/312500000\ne0.
\]

Its rank is three: it has no dependence on this support. This tests the
numerical-to-exact boundary directly. It does not claim the entire 56-row block
is feasible at the perturbed point; other infeasibility certificates may persist.

## Replay

Requirements: Python 3 and NumPy. No CUDA device, SciPy, SymPy, or paid service
is used.

```sh
python parent_pilot/structural/search_three_circuit.py --limit 128
python parent_pilot/structural/summarize_search.py
```

Numerical ordering and timing may vary across hardware or numerical libraries.
The frozen rational parents, exact signs, ranks and identities are the portable
certificate layer. `SEARCH_RESULT.json` stores every selected attempt, including
the full failure indices for the 27 rejected parents, and SHA-256 hashes of its
three source inputs. Independent verification is owned by the separate referee.
