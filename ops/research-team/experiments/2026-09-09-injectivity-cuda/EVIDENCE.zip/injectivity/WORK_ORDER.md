# Injectivity attack — 9 September 2026

User instruction: solve the injectivity. This explicitly opens a new attack on the original target; it does not authorize weakening it. GitHub head 59fec66666518257c585194b81061f60d91f439d, tree 9d3be78b6e8235af786c2ccb2ac24d977f12347a (PR49, open). This is a source snapshot plus additive research, not a full repository checkout. Historical source bytes are verified against Git blob identities in SOURCE_MANIFEST.json.

For every realizable uniform rank-four oriented matroid on eight elements and every three-element antichain of proper extension signatures, define Aij=Bi intersection Bj, T=B0 intersection B1 intersection B2 in the complete normalized parent realization space. Target D=(r01,-r02,r12): direct sum Hc1(Aij;Q) -> Hc1(T;Q) is injective. Include all components, internal equality/support strata and genuine parent infinity. Do not assume Hc0(T)=0. Accept established single-bad Hc0,Hc1,Hc2 vanishing and pair Hc0 vanishing, subject to source audit.

Opening ledger: 2/9. Original pair and triple invariants open; all seven operational obligations open; pair coverage and residual UNKNOWN. Triple source residue 1,162,302 is not a component count. No automatic full-diagonal promotion even if injectivity is proved.

Roles and owned surfaces:
- Coordinator: source reconciliation, integration, proof ledger, archive; root files only.
- Prover: actual geometric proof, including a stronger pair Hc1-vanishing route if valid; prover/ only.
- Falsifier: exact global/abstract end-incidence tests; distinguish original-domain counterexamples from abstract models; falsifier/ only.
- Referee: independent source audit, then frozen mathematical and computational review; referee/ only.

Discovery ceiling: 25 minutes per proof/falsification track for the initial attack. A structural null must identify the precise surviving geometry; no blind budget expansion. Exact progress can justify a concrete follow-through. Referee opening budget 10 minutes; closing review follows frozen candidates. No paid compute, external human messages, or destructive writes. Current research artifacts remain unpublished until separately directed; prior PR49 is read-only in this cycle.

Positive deliverable: proof of the exact universal map with every geometric comparison checked. Negative deliverable: original-domain certified kernel, or explicitly scoped counterexample to a proposed inference. Null deliverable: exact attempted mechanisms, failed hypotheses and a discriminating remaining obligation, with reproducible artifacts. Every status requires independent scope audit. Only coordinator may recommend theorem-credit changes.

Replay: independent exact rational cochain/determinant checks if finite artifacts arise; no float-based acceptance. Source hashes and boundaries checked independently. Freeze candidate digests before referee handoff. Save report and all new proofs, code, certificates and reviews as a durable checkpoint with a recovery mirror in the existing Projects/research-backups folder.
