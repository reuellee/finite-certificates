#!/usr/bin/env python3
"""Exact replay for the ABSTRACT common-row Gordan end-cycle model.

Python standard library only. This verifies its finite relative cochains,
exact rational feasible anchors, common-row rank, and a forbidden normal-ray
collision. The all-parameter elimination is proved in FINDINGS.md.
"""
import itertools
import json
from fractions import Fraction as Q
from pathlib import Path


def rank(rows, ncols=None):
    a = [[Q(x) for x in row] for row in rows]
    if not a:
        return 0
    ncols = len(a[0]) if ncols is None else ncols
    pivot = 0
    for col in range(ncols):
        found = next((r for r in range(pivot, len(a)) if a[r][col]), None)
        if found is None:
            continue
        a[pivot], a[found] = a[found], a[pivot]
        z = a[pivot][col]
        a[pivot] = [x / z for x in a[pivot]]
        for r in range(len(a)):
            if r != pivot and a[r][col]:
                z = a[r][col]
                a[r] = [x - z*y for x, y in zip(a[r], a[pivot])]
        pivot += 1
        if pivot == len(a):
            break
    return pivot


def closure(maximal):
    return {tuple(f) for simplex in maximal for k in range(1, len(simplex)+1)
            for f in itertools.combinations(simplex, k)}


def relative_complex(simplices, infinity):
    cells = {k: sorted(s for s in simplices-infinity if len(s) == k+1)
             for k in range(3)}
    ds = []
    for k in range(2):
        columns = {s: j for j, s in enumerate(cells[k])}
        matrix = []
        for s in cells[k+1]:
            row = [0]*len(columns)
            for j in range(len(s)):
                face = s[:j]+s[j+1:]
                if face in columns:
                    row[columns[face]] += (-1)**j
            matrix.append(row)
        ds.append(matrix)
    d0, d1 = ds
    if d1:
        for row in d1:
            assert sum(row[j]*d0[j][0] for j in range(len(row))) == 0
    betti = [len(cells[0])-rank(d0),
             len(cells[1])-rank(d0)-rank(d1),
             len(cells[2])-rank(d1)]
    return cells, d0, d1, betti


CS = ((1, 1), (-1, 1), (1, -1))
WS = ((-1, -1), (1, -1), (-1, 1))


def normals(u, v, y):
    p = (Q(u), Q(v), -Q(u)-Q(v))
    h = 1-sum(Q(z)**2 for z in y)
    fixed = [[int(i == j) for j in range(4)] for i in range(4)]
    moving = [[p[i], -1, h*CS[i][0], h*CS[i][1]] for i in range(3)]
    return fixed+moving, p, h


def signs(i):
    return [1, 1, *WS[i], *[1 if j == i else -1 for j in range(3)]]


def witness(i, p, h):
    if h < 0:
        size = max(abs(x) for x in p)
        k = (size+1)/(-h)
    else:
        gap = min([p[i]]+[p[i]-p[j] for j in range(3) if j != i])
        assert gap > 0
        k = gap/(8*(h+1))
    c, d = (k*z for z in WS[i])
    slopes = [p[j]+h*(CS[j][0]*c+CS[j][1]*d) for j in range(3)]
    lower = max([Q(0)]+[slopes[j] for j in range(3) if j != i])
    assert slopes[i] > lower
    return [Q(1), (slopes[i]+lower)/2, c, d]


def main():
    root = Path(__file__).resolve().parent
    model = json.loads((root/'MODEL.json').read_text())
    K = closure(model['ambient_maximal_simplices'])
    infinity = closure(model['infinity_maximal_simplices'])
    blocks = [closure(m) for m in model['bad_maximal_simplices']]
    assert set.union(*blocks) == K
    results = {}
    for i, B in enumerate(blocks):
        data = relative_complex(B, infinity)
        assert data[3] == [0, 0, 0]
        results[f'B{i}'] = data[3]
    pairs = list(itertools.combinations(range(3), 2))
    pair_data = []
    for i, j in pairs:
        A = blocks[i] & blocks[j]
        data = relative_complex(A, infinity)
        assert data[3] == [0, 1, 0]
        pair_data.append(data)
        results[f'A{i}{j}'] = data[3]
    T = set.intersection(*blocks)
    dataT = relative_complex(T, infinity)
    assert dataT[3] == [0, 2, 0]
    results['T'] = dataT[3]
    results['union'] = relative_complex(K, infinity)[3]
    assert results['union'] == [0, 0, 1]

    # Pair cocycles assign one to their isolated outer vertex's radial edge.
    # All radial edges survive, and all restrictions are the identity on C1.
    source_reps = []
    for (i, j), data in zip(pairs, pair_data):
        assert data[0][1] == dataT[0][1]
        missing = ({0, 1, 2}-{i, j}).pop()
        z = [int(k == missing) for k in range(3)]
        assert all(sum(a*b for a, b in zip(row, z)) == 0 for row in data[2])
        assert rank([[1, 1, 1], z]) == 2  # Not a coboundary.
        source_reps.append(z)
    # Target basis: e0,e1, with e2 = -e0-e1 mod the constant cochain.
    D = [[sgn*(z[0]-z[2]) for sgn, z in zip((1, -1, 1), source_reps)],
         [sgn*(z[1]-z[2]) for sgn, z in zip((1, -1, 1), source_reps)]]
    assert D == model['cohomology_D']
    assert rank(D) == 2
    kernel = model['primitive_kernel']
    assert all(sum(a*b for a, b in zip(row, kernel)) == 0 for row in D)
    for a, b in itertools.combinations(range(3), 2):
        assert rank([[row[a], row[b]] for row in D]) == 2
    assert [sum(sgn*x*z[k] for sgn, x, z in zip((1, -1, 1), kernel, source_reps))
            for k in range(3)] == [1, 1, 1]

    # Explicit primal anchors on each sector and in the common exterior.
    anchors = [(3, -1, [0]*7, [0]), (-1, 3, [0]*7, [1]),
               (-2, -1, [0]*7, [2]), (0, 0, [2]+[0]*6, [0, 1, 2]),
               (3, -1, [1]+[0]*6, [0])]
    count = 0
    for u, v, y, feasible in anchors:
        rows, p, h = normals(u, v, y)
        assert rank(rows) == 4
        assert all(any(x for x in row) for row in rows)
        for i in feasible:
            w = witness(i, p, h)
            assert all(s*sum(a*b for a, b in zip(row, w)) > 0
                       for row, s in zip(rows, signs(i)))
            count += 1
    # Uniform-parent obstruction: this exact point has duplicate moving rows.
    rows, _, h = normals(1, 1, [1]+[0]*6)
    assert h == 0 and rows[4] == rows[5] == [1, -1, 0, 0]
    assert rank(rows) == 4

    # Hostile canaries: omit a disk face, alter a kernel coordinate, and
    # replace the claimed collision point by an interior transverse point.
    damaged = K-{(0, 1, 2)}
    assert relative_complex(damaged, infinity)[3] != results['union']
    wrong = [1, 1, 1]
    assert any(sum(a*b for a, b in zip(row, wrong)) for row in D)
    noncollision, _, _ = normals(1, 1, [0]*7)
    assert noncollision[4] != noncollision[5]
    print(json.dumps({'status': 'PASS_ABSTRACT_ONLY', 'relative_betti_H0_H1_H2': results,
                      'D': D, 'primitive_kernel': kernel,
                      'rational_primal_anchors_checked': count,
                      'individual_injective_and_pairwise_independent': True,
                      'original_9DVL_counterexample': False,
                      'hostile_controls': 3}, indent=2))


if __name__ == '__main__':
    main()
