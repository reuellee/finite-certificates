# Independent falsifier: a common-row end cycle, and the geometry it violates

**Original injectivity: unresolved.** This track found no admissible uniform
rank-four parent/signature triple with a nonzero global kernel, and no proof
excluding such kernels. The new result is an exact **abstract countermodel**:
common polynomial Gordan rows, full rank, proper incomparable signatures,
all proved lower compact-support vanishings, nonempty exclusive-pair strata,
and even pairwise-independent injective restrictions do not imply the required
three-summand injectivity. The model fails a concrete original hypothesis:
some distinct rows become proportional, which distinct derived normals of a
uniform parent cannot do.

Base: PR49 head `59fec66666518257c585194b81061f60d91f439d`. Canonical inputs
are in `../source`; their digests are in `../SOURCE_MANIFEST.json`. This track
read no other worker's candidate artifacts and changes no original ledger.

## 1. Exact common polynomial row system

Let the ambient parent surrogate be

\[
 X=\mathbb R^2_{u,v}\times\mathbb R^7_y,
 \qquad p=(u,v,-u-v),\qquad h=1-\|y\|^2.
\]

Take a **single** polynomial matrix with seven rows in four private variables
`(a,b,c,d)`. Its first four rows are the standard basis. Its other rows are

\[
 a_i=(p_i,-1,h c_{i1},h c_{i2}),\qquad
 c_0=(1,1),\quad c_1=(-1,1),\quad c_2=(1,-1).
\]

The common matrix has rank four everywhere because the identity matrix is a
submatrix; no row ever vanishes because every moving row has second entry
`-1`. Signature `i` prescribes `a>0,b>0`, gives `(c,d)` the signs of

\[
 w_0=(-1,-1),\qquad w_1=(1,-1),\qquad w_2=(-1,1),
\]

and requires the moving row `i` positive and the other two moving rows
negative. These are three fixed sign reorientations of the same row matrix.
Gordan's alternative gives normalized compact convex witness fibers on every
bad locus, exactly as for an arbitrary strict homogeneous Gordan system.
This claim concerns common-row Gordan systems, **not** oriented-matroid
extension signatures derived from a uniform eight-column parent.

### Complete elimination of the private variables

Write `F_i` for strict feasibility and `B_i=X\F_i`. Then

\[
 F_i=\{h<0\}\ \cup\ \{p_i>p_j\text{ for both }j\ne i\}.
 \tag{1}
\]

Here is an all-parameter proof, including `h=0`. Suppose `h>=0`. On the
signature's open `(c,d)` quadrant, `c_i·(c,d)<0`, and
`(c_i-c_j)·(c,d)<=0` for every `j!=i`. The positive moving row therefore
forces `p_i>0`; subtracting each negative moving row forces `p_i>p_j`.
Conversely, if these strict inequalities hold, take `(c,d)=epsilon w_i`
with sufficiently small positive `epsilon`, set `a=1`, and choose `b>0`
strictly between the ith moving-row slope and the other two slopes.
Because `sum p_i=0`, strict maximality alone already implies `p_i>0`.

If `h<0`, take `(c,d)=k w_i` with `k` sufficiently large. The dot product
`c_i·w_i=-2`, while both other dot products are nonnegative. Consequently
the ith slope tends to positive infinity and neither other slope increases.
With `a=1`, choose `b` between the ith slope and the maximum of zero and
the other slopes. This proves feasibility for every `i`. The verifier
implements rational formulas for the small and large choices, checks seven
exact primal anchors, and leaves the general elimination proof explicit here.

Let `S_i` be the closed sector in the `(u,v)` plane on which `p_i` is maximal.
The three `S_i` tile the plane, meeting on the rays

\[
 r_0=(-2,1),\qquad r_1=(1,-2),\qquad r_2=(1,1).
\]

Equation (1) is therefore equivalent to

\[
 B_i=(\mathbb R^2\setminus\operatorname{int}S_i)\times D^7
     = (S_j\cup S_k)\times D^7.                 \tag{2}
\]

The transverse cap is the **closed** ball `D^7={||y||<=1}`. Its boundary
is inside the ambient space and is retained. Every `B_i` is full dimensional,
closed semialgebraic, ordinarily contractible, and noncompact. Every `F_i`
is nonempty and proper, and the three regions are pairwise incomparable:
interior sector points with `y=0` belong to exactly their own `F_i`.
All pairwise and triple good intersections are nonempty, containing `h<0`.

## 2. Global compact-support kernel and all lower checks

First compute in the plane, then multiply every set and every inclusion by
the compact contractible `D^7`. Projection and inclusion at its center are
proper, and their straight-line fiber homotopy is proper. Thus compact-support
cohomology and all restriction maps are preserved by this thickening. This
uses proper homotopy invariance, not ordinary homotopy invariance on arbitrary
noncompact spaces. A standard reference is Hatcher, *Algebraic Topology*,
Sections 3.3 and 3.H, [public text](https://pi.math.cornell.edu/~hatcher/AT/AT.pdf).

The plane admits a radial compactification by a disk triangulated as the cone
on a boundary triangle. Let its finite cone vertex be `o`, and let boundary
vertices `0,1,2` label the three rays `r_i`. The outer triangle boundary is
the genuine infinity subcomplex. For `B_i`, retain exactly the two triangles
on the boundary edges incident to vertex `i`. The finite simplicial data are
in `MODEL.json`, with numerical vertex `0` used for `o` and numerical vertices
`1,2,3` for the three infinity vertices.

Every compactified `B_i`, pair `A_ij`, and triple `T` is a cone and hence
contractible. Their infinity links are, respectively:

| Set | Infinity link | Compact-support groups in degrees 0,1,2 |
|---|---|---|
| `B_i` | a connected two-edge path | `(0,0,0)` |
| `A_ij` | one edge and the opposite isolated vertex | `(0,Q,0)` |
| `T` | three isolated vertices | `(0,Q^2,0)` |
| full bad union | the triangle boundary | `(0,0,Q)` |

Each pair and the triple has exactly one connected component, and it is
noncompact. Thus the triple compact-component obligation holds in this model.
Each exclusive pair `E_ij=A_ij\T` is an open planar sector times `D^7`,
homeomorphic to `R^2×D^7`, so it is nonempty and has `Hc1(E_ij)=0`.
Every single bad set in fact has zero compact-support cohomology in all
degrees, as do all single-exclusive sets `C_i`, which are empty. Every union
of two bad sets equals the full union and has `Hc1=0`. Consequently both
lower-diagonal vanishing patterns and the stronger single-bad two-skeleton
hypothesis are satisfied.

For the relative cellular complexes, `C0=Q`, the three radial edges form
`C1=Q^3`, and `d0(a)=(-a,-a,-a)`. An outer edge `ij` retained in a link
contributes the row `e_i-e_j` to `d1`. On `T`, there are no two-cells, so

\[
 H_c^1(T)=\mathbb Q^3/\langle(1,1,1)\rangle.
\]

On `A_ij`, the isolated radial edge `e_k` represents its nonzero `Hc1`
generator. Its restriction to `T` is the same class `[e_k]`. In target basis
`[e_0],[e_1]`, with `[e_2]=-[e_0]-[e_1]`, the actual alternating map is

\[
 D=\begin{pmatrix}-1&0&1\\-1&-1&0\end{pmatrix},
 \qquad \ker D=\mathbb Q\,(1,-1,1).                 \tag{3}
\]

The same primitive vector is integral. Each of the three source classes is
nonzero. Its alternating image at cochain level is `(1,1,1)=d0(-1)`, so the
image vanishes in cohomology. Each individual restriction is injective, and
any two image lines meet only in zero; every two-column minor of `D` is
nonzero. Hence the remaining failure is a genuinely three-summand relation,
not failure of individual restriction or pairwise image separation. This
also makes clear why no calculation of `Hc1` on a small open ball enters the
argument: (3) is computed on a complete global relative complex.

This example differs from the inherited graph-cylinder model, in which all
pair and triple sets coincide and the three maps have the same image. Here
the exclusive pairs are nonempty and every pair of image lines is independent.

## 3. Exact original-geometry obstruction

**Lemma.** For a uniform rank-four parent `Y`, derived normals belonging to
distinct three-element subsets cannot be proportional.

Each parent triple is independent, so its normal is nonzero and its kernel
is the three-dimensional span of that triple. Proportional normals would
give the same kernel. The union of two distinct triples contains at least
four parent labels, all lying in that three-dimensional subspace, contradicting
uniformity. This argument is independent of chart and normal rescaling.

Our common-row system violates this necessary condition at the finite point

\[
 (u,v)=(1,1),\qquad y=(1,0,\ldots,0),\qquad h=0:
 \quad a_0=a_1=(1,-1,0,0).                         \tag{4}
\]

The full seven-row matrix still has rank four and all rows remain nonzero.
Thus full rank of the whole row family cannot replace uniform-parent
normal-ray separation. At (4), signatures 0 and 1 demand opposite strict
signs of these identical rows, while signature 2 also fails the strict-max
test. This is a retained triple-bad point on the cap boundary.

It follows that this construction cannot be embedded as a fixed seven-row
subfamily of the 56 distinct derived normals on a uniform parent over its
whole original domain. Its cap uses row-collision events that the original
problem forbids. We have **not** proved that deleting those collisions kills
the kernel, that normal-ray separation alone guarantees injectivity, or that
every end cycle must use such a collision. Those are separate questions.
The original system also obeys all shared-column incidence and compound
Pluecker identities; the model does not certify these.

## 4. What a low-degree end reduction must still prove

For any compatible compactification `bar A` with genuine infinity `I_A`,
the ordinary relative long exact sequence gives

\[
0\to\operatorname{coker}[H^0(\bar A)\to H^0(I_A)]
 \to H_c^1(A)
 \to\ker[H^1(\bar A)\to H^1(I_A)]\to0.           \tag{5}
\]

The first term measures boundary-component differences; the last term can
carry ordinary one-dimensional cohomology of the compactification. Calling
all of `Hc1(A)` "ends" requires proving that last kernel zero. In this
countermodel all compactifications are cones, so it is zero and the entire
obstruction is an exact three-color boundary-component cycle. In the actual
original pair/triple spaces no complete compactification or corresponding
vanishing was supplied in the canonical sources. The lower single and pair
vanishings cannot impose the needed signed three-color boundary incidence,
even when this last term is absent, as (2)-(3) show.

The indispensable missing input is a theorem using **actual derived-normal
geometry**, not just common-row Gordan convexity, sparsity, ambient rank,
individual noncompactness, or pairwise restriction injectivity. One concrete
next discriminator is to test whether the three-color relation (3) can
survive in a full genuine parent compactification when all distinct normal
rays remain separate and the shared-column/compound identities are imposed.
A positive original realization needs all original admission and global
coverage data; a negative result needs a lemma excluding this end incidence,
not simply the observation that this particular surrogate has a collision.

## 5. Replay, scope, and useful null handoff

Run:

```sh
python -B injectivity/falsifier/verify_end_cycle.py
```

The standard-library replay reconstructs all simplicial faces and relative
incidence matrices, computes exact rational ranks, checks cocycle and
coboundary representatives, verifies the primitive kernel and pairwise image
independence, checks seven strict primal anchors and the rank-four collision,
and runs three hostile controls. It prints `PASS_ABSTRACT_ONLY`. Its all-point
semialgebraic elimination relies on the written elementary argument above;
sampled rational anchors are not presented as exhaustive coverage.

Searched route: low-degree compactification/ends, genuine three-color image
relations, and realization by a common polynomial Gordan row family. Surviving
gap: no original `Lambda^3 Y` parent geometry or original global pair complex.
No original obligation closed and no finite original residual reduced. This
is a scoped exact negative result for proposed sufficient hypotheses and a
NULL result for the requested original injectivity theorem. The independent
referee must decide acceptance; this track claims no self-certification or
ledger advancement.
