# Restore and replay this checkpoint

Extract the ZIP. It creates an `injectivity/` directory containing the consulted source subset and all current proofs, exact model data, code and reviews. This is an additive research checkpoint, not a full clone or Git history bundle.

From that directory, with Python 3 and no third-party dependencies:

```sh
python -B referee/verify_frozen_candidates.py
```

Expected verdict: `PASS_AUXILIARY_AND_ABSTRACT_ONLY`. Original injectivity remains `UNRESOLVED`; the theorem ledger is `2/9`. The checker verifies frozen source/artifact hashes and independently reconstructs the abstract result. The private-separator lemma is a written proof reviewed in `referee/FINAL_REVIEW.md`, not a claim certified by hash checks.

The producer replay is optional:

```sh
python -B falsifier/verify_end_cycle.py
```

`CHECKPOINT_MANIFEST.json` lists SHA-256 values for every payload file except itself and `CLEAN_RESTORE_REPLAY.json`. Those two exclusions avoid self-reference; the clean-replay record identifies the payload manifest that was checked. The ZIP format's integrity check covers every entry. Source Git blob identities are additionally in `SOURCE_MANIFEST.json` and `GITHUB_TREE.json`.

No historical branch, repository setting or theorem ledger needs to change to replay this checkpoint.
