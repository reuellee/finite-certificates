# Independent opening audit: original injectivity obligation

Role: independent referee/source auditor. This audit used canonical inputs only, before inspecting any current-cycle discovery output. No original theorem is advanced by this file.

Base revision: `59fec66666518257c585194b81061f60d91f439d`; tree: `9d3be78b6e8235af786c2ccb2ac24d977f12347a`. All 20 entries in the supplied `SOURCE_MANIFEST.json` matched independent SHA-256 calculations after the coordinator removed transfer-added terminal newlines to recover exact Git blob bytes. These inputs include the separately requested `THREE_SHEAR_SINGLE_PIECE_REDUCTION.md`, retrieved at the same pinned revision. Full local input accounting is in `SOURCE_AUDIT.json`.

## Verdict and scope

**OPENING_REDUCTION_ACCEPTED, WITH INHERITED-THEOREM BOUNDARY.** The actual alternating pair map and the double-boundary detector reduction are mathematically well formed. The checked reductions contain no discovered circularity or sign/variance error that resolves or changes the original injectivity question. The singleton proof's incidence/residence mechanism is coherent in its stated low-degree scope. It does not propagate automatically to exclusive strata or to simultaneous pair witnesses.

This is a written-proof dependency audit, not a replay of every inherited finite certificate, a proof-assistant validation, or an external-source verification of the parent-contractibility theorem. Inherited diagonal-two classification certificates and all 84,840 residual-wall certificates were not supplied for replay. They remain explicit assumed source dependencies; the current direct-map question does not need their source counts to define its target.

## Exact target and quantifiers

Use every realizable uniform rank-four oriented matroid M on eight labeled elements, its full normalized realization space X, and every three realizable uniform one-element extension signatures rho_0,rho_1,rho_2 with nonempty proper feasibility regions F_i that are pairwise incomparable under inclusion. The parent domain is the complete prescribed chirotope domain, not an individual residual chamber, a one-dimensional slice, or a selected chart sample. Arbitrary projective-frame changes must be transported, not treated as restrictions of the theorem.

Set B_i=X minus F_i (closed in X), A_ij=B_i intersection B_j, and T=B_0 intersection B_1 intersection B_2. The requested map is

    D : Hc1(A_01;Q) direct-sum Hc1(A_02;Q) direct-sum Hc1(A_12;Q)
        -> Hc1(T;Q),
    D(x01,x02,x12)=r01(x01)-r02(x02)+r12(x12),

where each r is compact-support cohomology restriction along a closed inclusion. The success condition is ker D=0 universally with those quantifiers. A proof that the three separate r maps are injective, or that their images meet pairwise trivially, does not suffice for three-way image independence.

## Compact supports and closed covers

All displayed spaces are locally compact semialgebraic sets, closed or locally closed in X. A common finite semialgebraic compactification and compatible triangulation supplies finite cochain models relative to true parent infinity. For closed-cover models, add the full common infinity subcomplex to the closures of the sets before restricting cochains. This handles extra closure intersections that occur only at infinity. The relative cellular restrictions are degreewise surjective and give the required closed-cover Mayer--Vietoris sequences.

For a closed inclusion T in A, the localization triangle is

    Cc(A minus T) -> Cc(A) -> Cc(T) -> Cc(A minus T)[1].

Thus restriction A -> T and a boundary map T -> (A minus T)[1] have the asserted variance. A closed inclusion alone does not give a degree-preserving extension-by-zero map from constant-coefficient cohomology of T back into A. Properness of inclusion does not repair that invalid variance.

Nonproper residence quotients in the singleton proof are not a defect: the construction uses R pi_!, not R pi_*. Its fiber stalks are compact-support cohomology and vanishing of all rows below d implies total vanishing below d. Nothing about the top row R^d pi_! follows from fiber escape alone.

## Lower vanishings and the third-diagonal split

The inherited source claims Hc^q(B_i;Q)=0 for q=0,1,2 and Hc0(A_ij;Q)=0. In the three-set closed-cover spectral sequence, total degree two then has only the surviving graded terms Hc0(T;Q) at (2,0) and ker D at (1,1). The possible d2 into (2,0) has source E2^(0,1)=0; no remaining higher differential can remove either term. Consequently

    Hc2(B_0 union B_1 union B_2;Q)=0
    iff Hc0(T;Q)=0 and ker D=0.

The filtration gives an extension of these two terms; any assertion of a canonical direct-sum decomposition needs additional justification. Over Q an abstract vector-space splitting exists, but its naturality is not supplied. This terminology issue does not affect the vanishing equivalence.

Importantly, injectivity of D is a meaningful separate target without assuming Hc0(T)=0. The older balanced-end short exact sequence does assume Hc0(T)=0 and must not be applied unconditionally in this cycle. Its conditional proof is sound: localization, the split map Cc(T)^3 -> Cc(T), and the homotopy-fiber triangle give the displayed short exact sequence once the degree-zero obstruction is removed.

## Double-boundary detector equivalence

For each i, with other indices j,k, define

    W_i=A_ij union A_ik,
    C_i=B_i minus (B_j union B_k),
    mu_i:Hc1(T)->Hc2(W_i),
    delta_i:Hc2(W_i)->Hc3(C_i),
    tau_i=delta_i mu_i,
    kappa_i=tau_i r_jk.

Closed-cover exactness gives ker mu_i=im r_ij + im r_ik. Singleton Hc2(B_i)=0 makes delta_i injective. Therefore ker tau_i=im r_ij + im r_ik. This verifies all signs and the claimed annihilation property; negating a summand has no effect on that image sum.

If all kappa_i are injective, applying each tau_i to D(x)=0 kills the incident summands and forces the opposite coordinate to vanish. Conversely, if kappa_i(x)=0, the image r_jk(x) is a sum of the other pair images and yields a relation in ker D with coordinate x up to sign. Thus D injective implies kappa_i injective. No injectivity of individual restriction maps and no triple Hc0 vanishing were smuggled into either direction.

**Acceptance boundary:** constructing kappa_i, proving their two automatic annihilations, or choosing algebraic left inverses conditional on injectivity does not prove their nondegeneracy. Claiming the nonzero-trace property without independent geometry is precisely a restatement of the original obligation.

## Singleton proof and generalization limits

The normalized Gordan resolution is proper because witness weights lie in a compact simplex; each nonempty fiber is convex. Coordinate support U and augmented rank r give a face of dimension k=|U|-r with r<=5. A limit loses support or, at fixed support, lowers rank. This supplies a finite filtration with stratum contributions Hc^(n-k)(D_U,k;orientation). The low-degree argument uses only k=0,1,2.

At k=0, |U|<=5 supplies either an omitted label or a degree-one label e and a degree-at-most-two label g outside e's triple. The source's plane-plus-pencil quotient has open three-dimensional residence fibers; fixing the pencil coordinate leaves a convex plane section. Each connected component retracts onto an interval. At k=1, |U|<=6 and total incidence <=18 supply a two-dimensional motion: a degree-zero/one label or at least two degree-two labels. With the incident plane rays retained, even shared-support two pencils give an open parameter domain with interval sections; each component is contractible. At k=2, |U|<=7 gives a label of degree <=2, hence an end that excludes compact components.

Retaining incident plane rays is essential: deleting a moving label alone loses the plane defined by that label and two others. The updated singleton note explicitly retains that data. Positive normal rescaling preserves exact support and face dimension and identifies the orientation system through the quotient; arbitrary pivot-minor signs need not remain fixed. This makes the restricted-stratum argument materially stronger than inferring its vanishing from the closed piece alone.

The mechanism has two sharp limits relevant to proposed proofs:

1. For a pair or triple of independent witness blocks, the union of selected supports can use substantially more than 5+k rows. The singleton degree count cannot be reused with the same bound.
2. For C_i (exactly one bad block), the other two blocks must remain good. Selected support-plane rescaling certifies only preservation of the selected bad witness. Those additional good-locus inequalities can truncate, disconnect, or otherwise change the residence fibers. The source provides no invariance theorem for them.

Furthermore, adding another motion and observing that every component trajectory escapes cannot kill the top compact-support component sheaf. The explicitly documented split-and-remerge example demonstrates why. Any proposed upgrade must control that sheaf or establish the new global fiber topology, not merely repeat proper-end language.

## Final candidate acceptance protocol

A positive handoff must provide a quantified deductive proof or a coverage-certified finite model for the actual original spaces and maps. It must identify zero-weight strata, simultaneous residual events, rank drops, projective-frame transport, and true parent infinity wherever the construction depends on them. Local cochains require a proved comparison to original compact-support cochains. Exact matrix rank on an uncompared subcomplex earns finite-model scope only.

Any finite claim will be independently recomputed from frozen raw inputs, with separate arithmetic/acceptance logic and appropriate positive, negative, null, and altered-input controls. A topological route countermodel will be labeled as such unless it satisfies the actual oriented-matroid parent and signature quantifiers. An auxiliary equivalence or a useful null result does not change 2/9. Even a proof of ker D=0 does not close diagonal three until the independent Hc0(T)=0 obligation is also proved.

Ready for coordinator-frozen candidate review. No current discovery outputs were inspected to prepare this opening audit.
