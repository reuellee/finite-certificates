#!/usr/bin/env python3
"""Independent exact replay. No discovery-side module is imported or executed."""
from fractions import Fraction as Q
from pathlib import Path
from itertools import combinations
import copy, hashlib, json
ROOT=Path(__file__).resolve().parents[1]
FROZEN={
 'prover/FINDINGS.md':'8eb2b24fa5a4094d83c4e74615599a49ee849ec9b8c02be8202e0acc998cbef3',
 'prover/HANDOFF.json':'d8c722cf729b87c9ecd30790858e140a6490a7547183a43ec865ff6f2457c64f',
 'falsifier/HANDOFF.json':'47ca906587f98d0736147f4caf5b81e1af599cdd2448dc45fdcb59b35e208825'}

def check(test,message):
 if not test: raise ValueError(message)

def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def ranks(a,ncols=None):
 a=[[Q(z) for z in row] for row in a]
 if not a: return 0
 r=0
 for c in range(len(a[0])):
  pivot=next((i for i in range(r,len(a)) if a[i][c]),None)
  if pivot is None: continue
  a[r],a[pivot]=a[pivot],a[r]
  t=a[r][c];a[r]=[z/t for z in a[r]]
  for i in range(r+1,len(a)):
   t=a[i][c]
   if t: a[i]=[x-t*y for x,y in zip(a[i],a[r])]
  r+=1
  if r==len(a): break
 return r

def closure(maxima):
 return {s for face in maxima for n in range(1,len(face)+1) for s in combinations(sorted(face),n)}

def complexes(faces,infty):
 cells={d:sorted(s for s in faces-infty if len(s)==d+1) for d in range(3)}
 ds={}
 for d in (0,1):
  cols={s:i for i,s in enumerate(cells[d])};rows=[]
  for sigma in cells[d+1]:
   row=[0]*len(cols)
   for k in range(len(sigma)):
    face=sigma[:k]+sigma[k+1:]
    if face in cols: row[cols[face]]+=(-1)**k
   rows.append(row)
  ds[d]=rows
 for row in ds[1]:
  for k in range(len(cells[0])):
   check(sum(row[j]*ds[0][j][k] for j in range(len(row)))==0,'d squared nonzero')
 dims=[len(cells[0])-ranks(ds[0]),len(cells[1])-ranks(ds[0])-ranks(ds[1]),len(cells[2])-ranks(ds[1])]
 return cells,ds,dims

C=[(1,1),(-1,1),(1,-1)]
W=[(-1,-1),(1,-1),(-1,1)]
SIG=[[1,1,*W[i],*[1 if j==i else -1 for j in range(3)]] for i in range(3)]
RAYS=[(-2,1),(1,-2),(1,1)]

def dot(a,b):return sum(x*y for x,y in zip(a,b))
def rowmat(u,v,h):
 return [[int(i==j) for j in range(4)] for i in range(4)]+[[p,-1,h*c[0],h*c[1]] for p,c in zip((u,v,-u-v),C)]
def feasibility(u,v,h,i):
 p=(u,v,-u-v);return h<0 or all(p[i]>p[j] for j in range(3) if j!=i)
def primal(u,v,h,i):
 p=(u,v,-u-v)
 if h>=0:
  delta=min([p[i]]+[p[i]-p[j] for j in range(3) if j!=i]);check(delta>0,'not good')
  t=delta/(8*(h+1))
 else:t=(sum(abs(a) for a in p)+1)/(-h)
 slopes=[p[j]+h*t*dot(C[j],W[i]) for j in range(3)]
 b=(slopes[i]+max([Q(0)]+[slopes[j] for j in range(3) if j!=i]))/2
 return [Q(1),b,t*W[i][0],t*W[i][1]]
def dual(u,v,h,i):
 p=(u,v,-u-v);j=next(j for j in range(3) if j!=i and p[j]>=p[i])
 lam=[Q(0)]*7;lam[0]=p[j]-p[i]
 for l in range(2):lam[2+l]=-h*(C[i][l]-C[j][l])*W[i][l]
 lam[4+i]=lam[4+j]=Q(1)
 total=sum(lam);return [z/total for z in lam]

# Polynomials in (u,v,h), stored as exponent-tuple dictionaries.
def add(a,b):
 out=dict(a)
 for m,c in b.items():out[m]=out.get(m,Q(0))+c
 return {m:c for m,c in out.items() if c}
def scale(a,t):return {m:c*t for m,c in a.items() if c*t}
def mul(a,b):
 out={}
 for m,c in a.items():
  for n,d in b.items():
   k=tuple(x+y for x,y in zip(m,n));out[k]=out.get(k,Q(0))+c*d
 return {k:v for k,v in out.items() if v}
ONE={(0,0,0):Q(1)};U={(1,0,0):Q(1)};V={(0,1,0):Q(1)};H={(0,0,1):Q(1)}
P=[U,V,add(scale(U,-1),scale(V,-1))]

def universal_dual_identities():
 rows=[[ONE if i==j else {} for j in range(4)] for i in range(4)]
 rows += [[P[i],scale(ONE,-1),scale(H,C[i][0]),scale(H,C[i][1])] for i in range(3)]
 count=0
 for i in range(3):
  check(dot(C[i],W[i])==-2,'own quadrant slope')
  for j in range(3):
   if i==j:continue
   check(dot(C[j],W[i])>=0,'competitor quadrant slope')
   w=[{} for _ in range(7)];w[0]=add(P[j],scale(P[i],-1));w[4+i]=w[4+j]=ONE
   for l in range(2):
    coeff=-(C[i][l]-C[j][l])*W[i][l];check(coeff>=0,'dual coefficient sign')
    w[2+l]=scale(H,coeff)
   for col in range(4):
    total={}
    for r in range(7):total=add(total,scale(mul(w[r],rows[r][col]),SIG[i][r]))
    check(total=={},'universal dual polynomial identity')
   count+=1
 return count

def inspect_model(model):
 check(model['classification']=='ABSTRACT_COMMON_ROW_GORDAN_COUNTERMODEL_NOT_ORIGINAL_9DVL','scope changed')
 check(model['signature_signs']==SIG,'signature signs mismatch')
 expected_rows=['e1','e2','e3','e4','(u,-1,h,h)','(v,-1,-h,h)','(-u-v,-1,h,-h)']
 check(model['matrix_rows']==expected_rows,'polynomial row metadata mismatch')
 ambient=closure([(0,1,2),(0,1,3),(0,2,3)]);infty=closure([(1,2),(1,3),(2,3)])
 check(closure(model['ambient_maximal_simplices'])==ambient,'ambient wrong')
 check(closure(model['infinity_maximal_simplices'])==infty,'true infinity wrong')
 bad=[]
 # Derive sector ownership from the strict-max equations, rather than producer labels.
 for i in range(3):
  triangles=[]
  for a,b in combinations(range(3),2):
   u=RAYS[a][0]+RAYS[b][0];v=RAYS[a][1]+RAYS[b][1];p=(u,v,-u-v)
   sector=max(range(3),key=lambda k:p[k]);check(sum(z==p[sector] for z in p)==1,'sector ambiguity')
   if sector!=i:triangles.append((0,a+1,b+1))
  bad.append(closure(triangles))
  check(bad[-1]==closure(model['bad_maximal_simplices'][i]),'bad sector assignment wrong')
 pair_order=[(0,1),(0,2),(1,2)]
 check(model['pair_order']==[list(x) for x in pair_order],'pair order changed')
 pairs=[bad[i]&bad[j] for i,j in pair_order];triple=bad[0]&bad[1]&bad[2]
 all_dims={}
 for name,sets,expected in [('singleton',bad,[0,0,0]),('pair',pairs,[0,1,0]),('triple',[triple],[0,2,0]),('union',[ambient],[0,0,1])]:
  all_dims[name]=[]
  for f in sets:
   _,_,dims=complexes(f,infty);check(dims==expected,'wrong cohomology '+name);all_dims[name].append(dims)
 for i,j in pair_order:check(bad[i]|bad[j]==ambient,'two-bad union incomplete')
 check(all(bad[i] <= (bad[(i+1)%3]|bad[(i+2)%3]) for i in range(3)),'single-exclusive nonempty unexpectedly')
 target_cells,target_d,_=complexes(triple,infty)
 check(target_cells[1]==[(0,1),(0,2),(0,3)],'target radial edges')
 check(target_d[0]==[[-1],[-1],[-1]],'d0 orientation')
 computed_columns=[];reps=[]
 for n,f in enumerate(pairs):
  cells,ds,_=complexes(f,infty)
  link_edges=[s for s in f&infty if len(s)==2]
  check(len(link_edges)==1,'pair link edge')
  isolated=next(k for k in (1,2,3) if k not in link_edges[0])
  vec=[int(s==(0,isolated)) for s in cells[1]]
  check(all(dot(row,vec)==0 for row in ds[1]),'source generator not cocycle')
  column_d0=[row[0] for row in ds[0]]
  check(ranks([column_d0,vec])==2,'source generator is a boundary')
  restriction=[vec[cells[1].index(e)] for e in target_cells[1]]
  q=[restriction[0]-restriction[2],restriction[1]-restriction[2]]
  sign=-1 if n==1 else 1;computed_columns.append([sign*x for x in q]);reps.append(restriction)
 actual_D=[[computed_columns[j][i] for j in range(3)] for i in range(2)]
 check(model['cohomology_D']==actual_D,'D differs from derived restriction')
 check(ranks(actual_D)==2,'wrong D rank')
 ker=model['primitive_kernel'];check(ker==[1,-1,1],'kernel fixture corrupted')
 check(all(dot(row,ker)==0 for row in actual_D),'kernel not annihilated')
 minors=[]
 for a,b in combinations(range(3),2):
  det=actual_D[0][a]*actual_D[1][b]-actual_D[0][b]*actual_D[1][a];check(det!=0,'pairwise image dependence');minors.append(det)
 cocycle=[sum(((-1 if j==1 else 1)*ker[j]*reps[j][r]) for j in range(3)) for r in range(3)]
 check(cocycle==[1,1,1],'kernel image representative');check(cocycle==[-row[0] for row in target_d[0]],'image not d0(-1)')
 collision=model['uniform_parent_forbidden_collision'];h=1-sum(Q(y)**2 for y in collision['y']);rows=rowmat(Q(collision['u']),Q(collision['v']),h)
 check(len(collision['y'])==7 and h==0,'collision cap boundary')
 r,s=collision['rows_equal'];check(r!=s and rows[r]==rows[s]==collision['equal_row'],'collision absent')
 check(ranks(rows)==4 and all(any(x for x in row) for row in rows),'rank/nonzero row condition')
 return {'cohomology_dimensions':all_dims,'derived_D':actual_D,'primitive_kernel':ker,'pairwise_minors':minors,'kernel_image_is_d0_minus_one':True,'collision_rank':4}

def main():
 for f,wanted in FROZEN.items():check(sha(ROOT/f)==wanted,'frozen hash '+f)
 source=json.loads((ROOT/'SOURCE_MANIFEST.json').read_text())
 for ent in source['files']:check(sha(ROOT/'source'/ent['path'])==ent['sha256'],'source hash '+ent['path'])
 fh=json.loads((ROOT/'falsifier/HANDOFF.json').read_text())
 for f,h in fh['artifacts'].items():check(sha(ROOT/'falsifier'/f)==h,'falsifier artifact '+f)
 ph=json.loads((ROOT/'prover/HANDOFF.json').read_text())
 for ent in ph['files']:check(sha(ROOT/'prover'/ent['path'])==ent['sha256'],'prover input '+ent['path'])
 raw=(ROOT/'prover/sources/DOUBLE_CONTRACTION_FIBERS.md').read_bytes()
 check(len(raw)==8135 and hashlib.sha1(('blob '+str(len(raw))+'\0').encode()+raw).hexdigest()=='a5003382eeeb50f396a78f32486f210dd6d6737f','external source exact Git blob')
 model=json.loads((ROOT/'falsifier/MODEL.json').read_text());result=inspect_model(model)
 result['universal_polynomial_dual_identities']=universal_dual_identities()
 pc=dc=0
 for u in [Q(-2),Q(-1),Q(0),Q(1,2),Q(1),Q(2)]:
  for v in [Q(-2),Q(-1),Q(0),Q(1,2),Q(1),Q(2)]:
   for h in [Q(-2),Q(0),Q(1,2),Q(1)]:
    rows=rowmat(u,v,h)
    for i in range(3):
     if feasibility(u,v,h,i):
      x=primal(u,v,h,i);check(all(SIG[i][r]*dot(row,x)>0 for r,row in enumerate(rows)),'strict primal anchor');pc+=1
     else:
      lam=dual(u,v,h,i);check(min(lam)>=0 and sum(lam)==1,'normalized dual weights')
      check(all(sum(lam[r]*SIG[i][r]*rows[r][c] for r in range(7))==0 for c in range(4)),'dual anchor');dc+=1
 result['rational_formula_anchors']={'primal':pc,'dual':dc,'scope':'regression only; universal claims use written proof and polynomial identity families'}
 controls=[]
 for name,mutate in [
  ('wrong_alternating_D',lambda m:m['cohomology_D'][0].__setitem__(0,1)),
  ('omit_actual_infinity_edge',lambda m:m['infinity_maximal_simplices'].pop()),
  ('wrong_sector_cover',lambda m:m['bad_maximal_simplices'][0].pop()),
  ('wrong_kernel',lambda m:m.__setitem__('primitive_kernel',[1,1,1])),
  ('signature_flip',lambda m:m['signature_signs'][0].__setitem__(4,-1)),
  ('false_collision',lambda m:m['uniform_parent_forbidden_collision'].__setitem__('v',2)),
  ('false_original_scope',lambda m:m.__setitem__('classification','ORIGINAL_9DVL_COUNTEREXAMPLE'))]:
  changed=copy.deepcopy(model);mutate(changed)
  try:inspect_model(changed)
  except ValueError:controls.append({'name':name,'rejected':True})
  else:raise ValueError('hostile input accepted '+name)
 result['hostile_controls']=controls
 result['verdict']='PASS_AUXILIARY_AND_ABSTRACT_ONLY'
 result['original_injectivity']='UNRESOLVED'
 result['ledger']='2/9'
 result['producer_imports_or_execution']=False
 result['prover_deductive_lemmas']='Written review in FINAL_REVIEW.md; hashes alone are not mathematical verification.'
 print(json.dumps(result,indent=2))
if __name__=='__main__':main()
