# Working backward from a hypothetical proof of 9DVL

Research design note, 9 September 2026. **The theorem ledger remains 2/9.**

The user's proposal is to assume that a positive proof exists and ask what must then be true or false. This note applies that idea to diagonal three (D3). It derives necessary consequences, identifies which implications can be reversed, and gives exact countermodels to tempting shortcuts. It does not construct a new geometric proof or counterexample.

The inputs are the public repository at commit `9e77c365b266e9d884e6ac14a0443992bec92c64`. This is a bounded logical audit of that snapshot, not a claim to have reconciled later unpublished checkpoints or opened a new construction cycle. Repository files and canonical state were not modified.

## 1. The logic of the approach

Write T for the target theorem and C for a proposed consequence. Establishing `T ⇒ C` makes C a useful prediction: an exact counterexample to C would refute T. Proving C independently proves T only when a reverse implication `C ⇒ T` is also established. A condition S with `S ⇒ T` is a sufficient proof route; T need not imply S.

Assuming truth does not warrant assuming a short proof, a bounded number of cells, small rational coefficients, a common escape direction, or any particular certificate architecture. These are additional hypotheses to test.

## 2. The existing exact D3 reduction

Fix any realizable uniform rank-four parent oriented matroid on eight elements and any three-element antichain of valid proper extension signatures. All spaces below are the actual loci over the whole normalized parent realization space, including every component and needed chart. Use rational coefficients.

Let

\[
B=B_0\cup B_1\cup B_2,\quad
P_{ij}=B_i\cap B_j,\quad
T=B_0\cap B_1\cap B_2,
\]

and define the alternating restriction map

\[
R:\bigoplus_{i<j}H_c^1(P_{ij};\mathbb Q)\longrightarrow H_c^1(T;\mathbb Q),
\qquad R(a,b,c)=r_{01}(a)-r_{02}(b)+r_{12}(c).
\]

The source's established lower inputs are singleton vanishing in degrees 0, 1 and 2, and pair-intersection vanishing in degree 0. Assume the source's convergent compact-support spectral sequence for the finite closed bad-locus cover, in the locally compact Hausdorff semialgebraic setting. Its total-degree-two filtration gives

\[
0\longrightarrow H_c^0(T;\mathbb Q)
\longrightarrow H_c^2(B;\mathbb Q)
\longrightarrow\ker R\longrightarrow0.
\]

This is a filtration exact sequence, not a canonical direct-sum decomposition. The two possible incoming differentials to the triple degree-zero term have zero sources by the lower inputs. The pair degree-one kernel has no surviving incoming or outgoing higher differential. The singleton degree-two term is zero.

Consequently, for each admissible parent and signature triple,

\[
\boxed{\mathrm{D3}\iff H_c^0(T;\mathbb Q)=0\ \text{and}\ R\text{ is injective}.}
\]

Universal D3 requires this for every admissible choice. The reduction is already in [the joined-flow note, section 6](https://github.com/reuellee/finite-certificates/blob/9e77c365b266e9d884e6ac14a0443992bec92c64/ai/omreal/DIAG3_JOINED_FLOW_TRIANGLE.md), with scope clarified in [the theorem prospectus](https://github.com/reuellee/finite-certificates/blob/9e77c365b266e9d884e6ac14a0443992bec92c64/ai/omreal/9DVL_THEOREM_PROSPECTUS.md). This audit does not rerun all earlier geometric proofs or certify an incomplete carrier as a model of the actual spaces.

## 3. Predictions of a positive proof

| Consequence | Logical status | What a failure would establish |
|---|---|---|
| Every connected component of the actual triple-bad locus is noncompact | Necessary | A certified compact component refutes D3 under the stated reduction |
| Each pair restriction map is injective | Necessary | A certified nonzero pair class restricting to zero refutes D3 |
| The three pair images have no nontrivial joint linear relation | Necessary; with individual injectivity, equivalent to injectivity of R | A certified cancellation tuple refutes D3 |
| `dim H_c^1(T) ≥ Σ dim H_c^1(Pij)` | Necessary, not sufficient | A reversed exact dimension inequality refutes D3 |
| Every pair group is zero | Sufficient for the pair obligation, stronger than necessary | A nonzero pair group alone refutes neither D3 nor its pair obligation |

For finite-component locally compact semialgebraic spaces, compactly supported degree-zero cohomology has one rational generator for each compact connected component. A noncompact component may be bounded in a chosen coordinate chart; noncompactness is not synonymous with Euclidean unboundedness. Any geometric escape proof must approach genuine infinity of the parent space, not an artificial box edge or an internal chart seam. Abstract noncompactness does not supply one globally coherent family of escape certificates.

There is also a useful refinement. Put `Uij=Pij\T`, the locus where the selected pair is bad and the third signature is not bad. Once `H_c^0(T)=0`, the open/closed compact-support exact sequence gives

\[
H_c^1(U_{ij};\mathbb Q)\cong\ker r_{ij}.
\]

Thus D3 forces each exclusive-pair group to vanish. Conversely, triple degree-zero vanishing, these three exclusive-pair vanishings, and joint independence of the three pair images suffice for D3. The exclusive-pair vanishings alone do not exclude mixed cancellation.

## 4. A proof target that allows nonzero pair groups

Instead of proving every pair group zero, seek a linear map on the actual cohomology groups

\[
L:H_c^1(T;\mathbb Q)\longrightarrow\bigoplus_{i<j}H_c^1(P_{ij};\mathbb Q),
\qquad LR=I.
\]

Such a rational left inverse exists exactly when R is injective. It recovers every pair class from its image on the triple locus while distinguishing it from the other pair contributions. No geometric retraction or integral inverse is required by this algebraic equivalence.

With complete finite models and the natural perfect compact-support/Borel–Moore pairing, the dual formulation is joint surjectivity of

\[
H_1^{\mathrm{BM}}(T;\mathbb Q)
\longrightarrow\bigoplus_{i<j}H_1^{\mathrm{BM}}(P_{ij};\mathbb Q).
\]

Its components are the signed proper pushforwards of the closed inclusions. Equivalently: for each pair class, find a triple class that maps to the desired class in that pair and to zero in the other two pairs. Separate surjectivity onto each pair is insufficient.

This is a concrete way to formulate what a positive proof would need to construct. It is an equivalent reformulation of the open pair obligation, not a new solution. The unproved geometric work remains: construct the maps or selective lifts, justify the global comparisons and genuine boundary, and independently exclude compact triple components. A left inverse on a sampled or partial complex does not establish the target.

## 5. Exact countermodels to invalid shortcuts

These examples are linear algebra, **not oriented-matroid counterexamples**.

1. **Nonzero pairs are compatible with injectivity.** Take each pair group to be Q and the triple group to be Q^3. The three coordinate embeddings give `R=diag(1,-1,1)`, an invertible map.
2. **Individual injectivity and the dimension bound are insufficient.** The matrix

   \[
   R=\begin{pmatrix}1&-1&0\\0&0&0\\0&0&1\end{pmatrix}
   \]

   has three nonzero columns and equal source and target dimensions, but rank 2 and kernel vector `(1,1,0)`.
3. **Pairwise disjoint images are insufficient.** The three lines spanned by `(1,0)`, `(0,1)` and `(1,1)` in Q^2 meet pairwise only at zero, yet the third vector is the sum of the first two. All three images must form an internal direct sum.
4. **Existence of a filler does not bound its size.** For arbitrarily large n, let boundaries of three-generators be `e_j-e_(j+1)` for `j<n` and `e_n` for `j=n`, with every e_j a two-cycle. The unique filler of e_0 is the sum of all n+1 generators. Vanishing holds, but the filler length in this chosen basis grows without bound.
5. **Rational vanishing need not be integral vanishing.** A boundary matrix `[2]` is invertible over Q but leaves an integral quotient Z/2. D3's rational target does not itself demand integral exactness.

The repository's no-common-root example likewise rules out its specified singleton elementary-root filler model, not all possible proofs. An individual local three-chain is not automatically a global D3 certificate or a proof that every triple component escapes. The prospectus correctly allows a chain of several cells; a positive theorem does not force one specially shaped three-cell.

## 6. Result and next discriminating question

The proposal yields a disciplined search: derive a necessary consequence, attack it, and seek an independent proof of a conjunction known to imply D3. Here the useful focus is the exact combination of triple noncompactness and joint pair detection. It avoids imposing termwise pair acyclicity without justification.

The next substantive question is whether the actual geometry admits the selective lifts or detectors above. A proof must specify how they arise; the abstract fact that every injective map has a left inverse is not a construction. Failure to find a candidate proves nothing. An exact obstruction refutes D3 only after the candidate is identified with the actual globally defined groups and maps; otherwise it may refute only the selected proof architecture.

Three independent roles checked construction-side implications, false converses, and the spectral-sequence/scope boundary. Source bytes were matched to their Git blob identifiers. The algebraic canaries use exact rational arithmetic. The result is a checked proof-design map and useful nonconsequences; neither invariant D3 obligation has been discharged. **Ledger change: none.**

## Source integrity

| Source at the pinned commit | Git blob SHA-1 | SHA-256 of exact bytes |
|---|---|---|
| `ai/omreal/9DVL_THEOREM_PROSPECTUS.md` | `3a58ad74373e59852866d1754fad558ee417a449` | `9d7fa818ef48ec1df8d7cadc8525d6d705377f2f1294d9eba692dc15a2533cb7` |
| `ai/omreal/DIAG3_JOINED_FLOW_TRIANGLE.md` | `04ec99f1bb940fb0ce2fb9d7134731a28fb83f85` | `20aafd28f9624ca595a44e3124934baa4d33b942b6c8eca6bff210fedb114c8a` |
| `ai/omreal/data/CANONICAL_RESEARCH_STATE_V10.json` | `ca3fc88047004e383beca8860182e2748a4c3fbe` | `405e1f34789e999d2b8725881a4b99c1db81cec3ecfa70abcdfa9b3fbb7a46bf` |
