"""Verify frozen evidence bytes; this is not a proof checker."""
from hashlib import sha256
from pathlib import Path
import json

ROOT = Path(__file__).resolve().parent
record = json.loads((ROOT / "HANDOFF.json").read_text())
for item in record["files"]:
    path = (ROOT / item["path"]).resolve()
    digest = sha256(path.read_bytes()).hexdigest()
    assert digest == item["sha256"], f"Source/artifact mismatch: {path}"
assert record["result"] == "INCONCLUSIVE_ORIGINAL_INJECTIVITY"
assert record["original_obligations_closed"] == 0
assert record["triple_Hc0_assumed"] is False
print(f"PASS: {len(record['files'])} pinned files; theorem proof NOT asserted")
