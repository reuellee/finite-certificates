# Injectivity constructive track: global proof not obtained

**Classification: INCONCLUSIVE / NULL for the original injectivity obligation.**
No original obligation closed. No exhaustive source family was removed.
No original-space counterexample was found. The ledger remains 2/9.

Base: `59fec66666518257c585194b81061f60d91f439d` (PR49 head), as pinned by
the coordinator's source manifest. Work is confined to this directory; the
canonical source and ledger were not modified.

## 1. Target and permitted inputs

For every realizable uniform rank-four eight-element parent, over its whole
normalized realization space X, and every triple of pairwise incomparable
proper extension signatures, write

    Aij = Bi intersect Bj; T = B0 intersect B1 intersect B2;
    D(x01,x02,x12) = r01(x01) - r02(x02) + r12(x12).

The required conclusion is injectivity of D on the direct sum of rational
compact-support H1 groups. Singleton compact-support H0,H1,H2 and pair H0
vanishing are accepted inputs. Triple H0 vanishing is not assumed. All
components, zero Gordan weights, chart changes and true parent infinity
belong to the target.

The double-boundary detector construction in the pinned source is exact,
but proving its nondegeneracy is equivalent to the target. This track did
not treat that equivalence as a new geometric theorem.

## 2. Stronger pair-vanishing route: actual failure of the proof premise

A sufficient stronger statement would be Hc1(Aij)=0 for every pair. The
accepted singleton vanishings and closed Mayer--Vietoris identify this with
Hc2(Bi union Bj), hence, using the stated parent duality, with H6(Fi intersect
Fj). This is only a way to locate the stronger target.

I examined simultaneous contraction of the two private extension vectors.
At a generic independent pair, put them at e3,e4 and write the eight parent
columns as (a_s,h_s,k_s), with a_s in R2. The extension constraints involving
e3 and e4 are separate linear inequalities in k and h. But each parent
four-bracket is

    sum epsilon_ab det(a_c,a_d) (h_a k_b - h_b k_a),

where {c,d} complements {a,b} in the bracket. Thus the absence of prescribed
mixed-private brackets does not remove the bilinear parent constraints.
Fixing h makes the k-fiber convex; the feasible h-locus need not be convex.
The normalized rank-two base has dimension five and this one-row projection
still has a five-dimensional first-row locus. That count does not give the
required H6 vanishing or control nonproper specializations.

This is already explicitly covered in `DOUBLE_CONTRACTION_FIBERS.md`,
Sections 1--2. I fetched the exact pinned source and stopped this route upon
finding that match. It is not credited as a new reduction.

## 3. Actual good-locus lift: a precise boundary statement

The following auxiliary lemma makes clear what happens when one retains
private separating vectors to keep the other blocks good. It does not prove
the detector is nonzero.

Fix a signature rho, let A(Y) be its 56-by-4 signed actual derived-normal
matrix, and let F be its good locus. For Y in F define

    Q(Y) = {p in R4 : A(Y)p >= 1 coordinatewise},
    p*(Y) = argmin { ||p||^2 : p in Q(Y) }.

Here 1 is the vector with all entries one. This is a margin normalization
in Euclidean private-vector space, not a projective normalization.

**Lemma.** Q(Y) is nonempty exactly on F. The minimizer exists, is unique,
is semialgebraic, and depends continuously on Y in F. Its graph is closed
in X times R4. If Yn in F tends to an interior parent Y0 outside F, then
||p*(Yn)|| tends to infinity.

**Proof.** Strict feasibility permits scaling a separator until all margins
are at least one. Conversely a point of Q is a strict separator. A nonempty
closed polyhedron has a unique minimizer of the coercive strictly convex
squared norm. Its graph is semialgebraic by real quantifier elimination of
the optimality condition.

For continuity let Yn tend to Y in F. Choose p with A(Y)p>1 in every row;
it remains feasible near Y. Optimality bounds ||p*(Yn)|| by ||p||, so every
subsequence has a convergent subsubsequence, whose limit lies in Q(Y).
For any epsilon>0, (1+epsilon)p*(Y) has strict margin and is feasible at Yn
eventually. Optimality then gives

    limsup ||p*(Yn)|| <= (1+epsilon)||p*(Y)||.

Let epsilon decrease to zero. Every cluster point is a minimizer at Y and
hence equals p*(Y); this proves continuity. If Yn tends to Y0 in X and the
graph vectors have a finite limit p0, continuity of the inequalities gives
A(Y0)p0>=1, so Y0 is good, and the continuity just proved identifies the
limit with p*(Y0). This proves closedness. If ||p*(Yn)|| did not tend to
infinity at a bad Y0, a bounded subsequence would supply such a separator,
a contradiction. QED.

The graph is homeomorphic to F. Its projection to F is consequently proper
as a map to F. Its projection to X is generally not proper: a compact set
of parents can contain a sequence approaching a bad point whose graph
vectors diverge. No improper pushforward is replaced by a proper one here.

For the single-exclusive stratum Ci=Bi minus (Bj union Bk), using the two
maps p*j,p*k gives the same closed graph in Bi times R8. A limit over an
interior parent leaving Ci must send at least one of the two margin-normalized
vectors to infinity. This is a private-vector boundary over a finite parent.
Projectively normalizing the vector to a unit direction can remove its norm
divergence. Therefore this does not establish true parent escape, a new end
of the original parent realization space, or nondegeneracy of kappa_i.

### The actual source boundary used

`DOUBLE_CONTRACTION_FIBERS.md`, Section 3, supplies an actual row-2599
affine parent path e(u)=2R+u(L-R), 0<=u<=2. One extension remains good along
the path. A second fixed signature is good at both endpoints and is bad on
the entire interval [1/2,3/2], by an exact five-row positive circuit. All
parents remain in the same strict uniform parent domain.

Openness of the second good locus and closedness of the complementary bad
locus imply an interior first boundary point u* in (0,1/2] when traveling
from zero. Along any good sequence approaching u*, the lemma forces the
second least-norm separator to diverge. This uses the interval certificate,
not the later support-change event at which no bad-to-good transition was
established. The location u* and an explicit minimizer formula were not
computed, and the source arithmetic was not rerun in this lane.

## 4. Where actual derived-normal equations enter

The generic common-row Gordan formalism cannot itself supply the missing
attachment theorem. The actual rows satisfy a stronger, very concrete
constraint. For distinct triples I,J select e in I minus J and f in J minus I.
Writing aI(v)=det(Y_I,v), one has

    aI(y_e)=aJ(y_f)=0,
    aI(y_f)=det(Y_I,y_f) != 0,
    aJ(y_e)=det(Y_J,y_e) != 0.

Consequently

    (aI wedge aJ)(y_e,y_f)
       = -det(Y_I,y_f) det(Y_J,y_e) != 0.

Signs depend only on the fixed ordered parent brackets. No two distinct
actual derived normals are proportional anywhere inside the uniform parent
space. This identity follows directly from the source definition and
uniformity; it is not an unproved generic-position assumption. It forbids
an interior cap whose mechanism merges two distinct signed rows into one
projective ray. It does not forbid all three-way incidence cycles.

Further constraints that a real proof must use are the exact exterior
kernel identity

    ker(Lambda^3 T_Y) = ker(T_Y) wedge Lambda^2 R8,

the common parent and extension Grassmann--Pluecker sign axioms, and the
fixed-unit three-/four-circuit relations (27a),(27c) of ATLAS_HELLY Section 12.
Those fixed-unit relations make every aligned extension globally one-sided
at its active residual wall. They restrict which oriented local boundaries
can occur. No implication from these restrictions to exclusion of every
global signed split/merge cycle was obtained.

## 5. Precisely surviving issue and stop decision

Retaining good private vectors makes a chosen support-plane residence
motion linear in the moving parent column: the good inequalities cut its
residence domain by strict affine halfspaces. But projecting those private
vectors away introduces an existential feasibility condition; the actual
row-2599 gap shows that a single parent-motion line can be truncated at an
interior feasibility boundary. The least-norm graph records this truncation
as private-vector infinity. A proof must distinguish these faces from true
parent infinity and determine their signed incidence with the other two
blocks, across all admissible small-circuit specializations.

I did not construct those original global incidence maps or a theorem that
makes their signed traces nonzero. The surviving issue is exactly that
global geometric attachment, subject to the concrete third-compound and
fixed-parent-sign equations above. It is not a matrix rank condition newly
advertised as a solution. No bounded universal elimination family was
produced, so there is no justification for an F4SAT run or a larger census
on the output of this lane.

Discovery freezes at this structural null. Repeating the private-vector
convexity or double-contraction argument is not an eligible same-route
continuation. Useful next work would need a genuinely new attachment
construction that handles the private boundary faces; this lane does not
claim that such a construction has been supplied.

## 6. Sources and verification limits

All statements use the pinned repository revision. Primary project sources:

* `ai/omreal/ATLAS_HELLY.md`: Sections 2, 4.2--4.3, 12.
* `ai/omreal/DIAG3_SINGLE_BAD_TWO_SKELETON.md`: singleton inputs and exact
  support-plane transport.
* `ai/omreal/DIAG3_PAIR_DIFFERENTIAL_ENDS.md`: global pair-map scope; its
  balanced-end short exact form assumes triple H0, which is not used here.
* `ops/team/d3-detector-prover/BOUNDARY_DETECTORS.md`: canonical kappa and
  its equivalence, with no triple H0 premise.
* `ai/omreal/DOUBLE_CONTRACTION_FIBERS.md`: fetched at the pinned revision
  into `sources/DOUBLE_CONTRACTION_FIBERS.md`; Git blob
  `a5003382eeeb50f396a78f32486f210dd6d6737f`.

No new arithmetic certificate or formal proof-assistant output is claimed.
The auxiliary norm-minimizer lemma is a deductive argument requiring
independent proof review. File integrity can be replayed with

    python -B verify_manifest.py

This command verifies source/artifact bytes only, not the global theorem.
