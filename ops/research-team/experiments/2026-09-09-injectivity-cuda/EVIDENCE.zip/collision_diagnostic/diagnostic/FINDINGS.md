# Full collision deletion: kernel removed, lower hypotheses lost

**Candidate outcome: exact abstract diagnostic, not original 9DVL.** After
deleting every proportional pair of distinct rows, all pair and triple
compact-support groups in degree one vanish. The alternating map is the
unique map from zero to zero. However, every singleton acquires
`H_c^2 = Q^8`. The deletion therefore does not retain the lower hypotheses of
the original countermodel. Original injectivity remains open and the ledger
remains 2/9. This document is a discovery proof pending independent review.

## 1. Complete collision locus, including coordinate rows

Use exactly the frozen model: `p=(u,v,-u-v)`, `h=1-||y||^2`, four coordinate
rows and `a_i=(p_i,-1,h c_i)` with `c_0=(1,1)`, `c_1=(-1,1)`,
`c_2=(1,-1)`. Coordinate rows never collide. A moving row cannot be
proportional to `e_1,e_3,e_4` because its second coordinate is -1. It is
proportional to `e_2` precisely when `p_i=h=0`. Two moving rows are
proportional precisely when they are equal (second coordinate -1 fixes the
factor), hence precisely when `h=0` and `p_i=p_j`. Their distinct `c_i`
ensure necessity of `h=0`.

Thus the complete closed collision set is

\[
 C=L\times S^6,\qquad
 L=\{u v(u+v)(u-v)(2u+v)(u+2v)=0\}.
\]

These are six distinct lines through the origin, comprising twelve rays.
This accounts for all 21 pairs: six coordinate/coordinate pairs, nine
automatically separated coordinate/moving pairs, three `e_2`/moving pairs,
and three moving/moving pairs. Merely deleting the last three lines misses,
for example, `(u,v,h)=(0,1,0)`, where `a_0=-e_2` and no moving pair collides.

Put `X'=X\C`. Feasibility is unchanged at surviving points because the row
system and signatures have not changed. By the frozen all-parameter
elimination, `B_i'=B_i\C`, with

\[
 B_i'=(K_i\times D^7)\setminus((K_i\cap L)\times S^6),
 \qquad K_i=\mathbb R^2\setminus\operatorname{int}S_i.
\]

The retained cap is partially punctured on its boundary; it is **not**
replaced by an open ball in the singleton or pair spaces.

## 2. Planar arrangement and the natural restriction maps

Each closed maximality sector `S_i` has two maximal-tie boundary rays and
three interior collision rays (one minimum-tie ray, two zero-coordinate
rays). It therefore comprises four angular cells. Each `K_i` has nine
collision rays and eight angular cells. Each planar pair `K_i∩K_j` is the
remaining closed sector plus an isolated maximal-tie ray, giving six rays
and four angular cells. The planar triple is the three maximal-tie rays,
giving three rays and zero angular cells. The replay constructs the rays
from the six linear forms, sorts them by exact cross products, and derives
each sector membership from the signs of `p_i-p_j`; it does not accept these
counts as geometric input.

For a planar cone `K`, let `J=K∩L`, a star of `m` closed rays. The removed
closed subset in `Z=K×D^7` is `E=J×S^6`. In degrees 0,1,2 its compact-support
groups equal those of `J`, because `S^6` is compact and its only rational
cohomology is in degrees 0 and 6. In particular `H_c^0(E)=0` and
`H_c^1(E)=Q^m/⟨(1,...,1)⟩`.

The closed-inclusion restriction `H_c^1(Z)→H_c^1(E)` comes directly from
restricting planar radial-edge cochains. For a singleton the source is zero.
For a pair, the generator is the cochain supported on its isolated ray;
its restriction is the same standard coordinate class in
`Q^6/⟨1⟩`, hence is nonzero and injective. For the triple, both spaces have
the same three-ray cochain quotient; the restriction is the identity on
`Q^3/⟨1⟩`. These descriptions also establish naturality for every inclusion
in the three-set diagram. Sphere degree six contributes separately in
degree seven and must not be counted as an additional degree-one group.

The closed/open compact-support exact sequence is

\[
\cdots\to H_c^q(Z\setminus E)\to H_c^q(Z)
 \to H_c^q(E)\to H_c^{q+1}(Z\setminus E)\to\cdots.
\]

It follows that each deleted singleton has `H_c^1=0,H_c^2=Q^8`; each deleted
pair has `H_c^1=0,H_c^2=Q^4`; the deleted triple has `H_c^1=H_c^2=0`.
Every degree-zero group vanishes. Thus all the requested lower checks
survive except singleton `H_c^2=0`, which fails for every singleton.

## 3. Direct finite relative complex with all new ends

The exact replay also computes the groups directly, independently of the
dimension extraction from that exact sequence. Radially compactify the
plane to the cone on the twelve-ray polygon. For each `K`, keep its angular
triangles, rays, and origin, with the polygon subcomplex as planar infinity.
Use the three-cell CW pair `(D^7,S^6)`: a zero-cell `s`, a six-cell `t`, and
a seven-cell `d`, with `∂d=t` and other cellular boundaries zero. The correct
closed infinity set in the product compactification is

\[
 I=(I_K\times D^7)\cup(\overline{K\cap L}\times S^6).
\]

The second summand includes the closure at planar infinity and records
every newly deleted end. The compactification minus `I` is precisely the
deleted space, so its relative cellular cochains compute compact-support
cohomology. The product differential is
`∂(σ×c)=(∂σ)×c+(-1)^dimσ σ×∂c`.

If `m` is the number of collision rays and `n` the number of angular cells,
the surviving relative cochain dimensions are `C^2=Q^n`, `C^7=Q`,
`C^8=Q^(m+n)`, and `C^9=Q^n`, and zero otherwise. In appropriate oriented
bases, `d^7` sends the origin to minus the all-ones radial vector, while
`d^8=[M I_n]`, where `M` is the angular triangle/radial-edge incidence matrix.
Thus `rank d^7=1`, `rank d^8=n`, and all groups are

| Space | m | n | Nonzero compact-support groups |
|---|---:|---:|---|
| Each singleton | 9 | 8 | Hc2=Q8; Hc8=Q8 |
| Each pair | 6 | 4 | Hc2=Q4; Hc8=Q5 |
| Triple | 3 | 0 | Hc8=Q2 |

All nine-dimensional groups vanish. As a check special to the triple,
its entire boundary sphere is deleted because its planar part is contained
in `L`; hence `T'=T_plane×int(D^7)`, consistently shifting its old degree-one
group to degree eight. That replacement is valid only for the triple.

At cochain level, every restriction in the deleted diagram is coordinate
restriction on shared product cells. The replay reconstructs these maps
and checks their commutation with the differentials. The degree-one
cochain spaces themselves are zero, so the induced alternating map is

\[
 D':0\oplus0\oplus0\longrightarrow0,\qquad\ker D'=0.
\]

## 4. Meaning, replay boundary, and useful null

The old degree-one kernel disappears in this deletion experiment, while
degree-two singleton classes appear from the new boundary components. This
does not prove that nonproportionality forces injectivity in every system;
nor does it establish a compatible deformation retaining all required
lower vanishings. The full seven-row family still has identity rank four,
no zero rows, fixed incomparable signatures and proper nonempty good sets
on `X'`; the center `y=0` witnesses properness and incomparability. What
fails is explicitly the lower singleton cohomology hypothesis, independently
of the still absent shared-column and compound identities.

Run `python -B diagnostic/verify_deletion.py` from the cycle directory.
The standard-library verifier derives all 21 proportionality conditions,
constructs the twelve-ray arrangement and relative cellular complexes,
checks all natural restriction cochain maps, and reports exact rational
dimensions. It also rejects omitted coordinate collisions, the old
infinity set, and indiscriminate replacement by an open cap. The topology
identifying this finite relative CW pair with the semialgebraic space is
the written proof above; the checker does not purport to be a formal proof
assistant or to certify original parent geometry.

Useful null: **full collision deletion of this frozen model cannot supply
an admissible countermodel preserving the required lower vanishings**.
No original source orbit was resolved, no original obligation was closed,
and the original ledger is unchanged at 2/9.
