#!/usr/bin/env python3
"""Exact small cellular replay. No imports from producer/prior checkers."""
from fractions import Fraction as F
from functools import cmp_to_key
from itertools import combinations
from math import gcd
import json
import time


def rank(a):
    a = [[F(x) for x in row] for row in a]
    r = 0
    for j in range(len(a[0]) if a else 0):
        pivot = next((i for i in range(r, len(a)) if a[i][j]), None)
        if pivot is None:
            continue
        a[r], a[pivot] = a[pivot], a[r]
        z = a[r][j]
        a[r] = [x/z for x in a[r]]
        for i in range(len(a)):
            if i != r and a[i][j]:
                z = a[i][j]
                a[i] = [x-z*y for x, y in zip(a[i], a[r])]
        r += 1
        if r == len(a):
            break
    return r


ZERO = (0, 0, 0)


def poly(**kw):
    return {tuple(map(int, k)): v for k, v in kw.items() if v}


def add(a, b, s=1):
    z = dict(a)
    for k, v in b.items():
        z[k] = z.get(k, 0)+s*v
    return {k: v for k, v in z.items() if v}


def mul(a, b):
    z = {}
    for k, v in a.items():
        for l, w in b.items():
            key = tuple(x+y for x, y in zip(k, l))
            z[key] = z.get(key, 0)+v*w
    return {k: v for k, v in z.items() if v}


def collision_audit():
    one, neg, h = {ZERO: 1}, {ZERO: -1}, {(0, 0, 1): 1}
    ps = [{(1, 0, 0): 1}, {(0, 1, 0): 1},
          {(1, 0, 0): -1, (0, 1, 0): -1}]
    cs = [(1, 1), (-1, 1), (1, -1)]
    rows = [[one if i == j else {} for j in range(4)] for i in range(4)]
    rows += [[p, neg, {k: v*c[0] for k, v in h.items()},
              {k: v*c[1] for k, v in h.items()}] for p, c in zip(ps, cs)]
    records, forms = [], set()
    for i, j in combinations(range(7), 2):
        minors = [add(mul(rows[i][a], rows[j][b]),
                      mul(rows[i][b], rows[j][a]), -1)
                  for a, b in combinations(range(4), 2)]
        if i < 4 and (j < 4 or i != 1):
            assert any(z == one or z == neg for z in minors)
            records.append({'rows': [i, j], 'condition': 'never'})
            continue
        q = ps[j-4] if i == 1 else add(ps[i-4], ps[j-4], -1)
        # A pure nonzero multiple of h is among the actual wedge minors.
        assert any(set(z) == {(0, 0, 1)} for z in minors)
        # At h=0 all remaining minors are zero or multiples of exactly q.
        restricted = [{k: v for k, v in z.items() if k[2] == 0} for z in minors]
        nonzero = [z for z in restricted if z]
        assert nonzero
        for z in nonzero:
            key = next(iter(q))
            factor = F(z.get(key, 0), q[key])
            assert z == {k: factor*v for k, v in q.items()}
        a, b = q.get((1, 0, 0), 0), q.get((0, 1, 0), 0)
        g = gcd(abs(a), abs(b))
        a, b = a//g, b//g
        if a < 0 or (a == 0 and b < 0):
            a, b = -a, -b
        forms.add((a, b))
        records.append({'rows': [i, j], 'condition': {'h': 0, 'linear_form': [a, b]}})
    assert len(records) == 21 and len(forms) == 6
    return sorted(forms), records


def ray_compare(a, b):
    half = lambda v: 0 if v[1] > 0 or (v[1] == 0 and v[0] > 0) else 1
    if half(a) != half(b):
        return -1 if half(a) < half(b) else 1
    cross = a[0]*b[1]-a[1]*b[0]
    return -1 if cross > 0 else (1 if cross < 0 else 0)


def arrangement(forms):
    rays = set()
    for a, b in forms:
        rays.add((b, -a))
        rays.add((-b, a))
    return sorted(rays, key=cmp_to_key(ray_compare))


def faces(simplex):
    return {s for k in range(1, len(simplex)+1) for s in combinations(simplex, k)}


def bad(i, v):
    p = (v[0], v[1], -v[0]-v[1])
    return any(p[i] <= p[j] for j in range(3) if j != i)


def cover(rays):
    singles = []
    n = len(rays)
    for i in range(3):
        k = {(0,)}
        for t, v in enumerate(rays):
            if bad(i, v):
                k |= faces((0, t+1))
            w = rays[(t+1) % n]
            midpoint = (v[0]+w[0], v[1]+w[1])
            if bad(i, midpoint):
                k |= faces(tuple(sorted((0, t+1, (t+1) % n+1))))
        singles.append(k)
    spaces = {str(i): singles[i] for i in range(3)}
    spaces.update({f'{i}{j}': singles[i] & singles[j] for i, j in combinations(range(3), 2)})
    spaces['012'] = singles[0] & singles[1] & singles[2]
    return spaces


CAP_DEG = {'s': 0, 't': 6, 'd': 7}


def complex_for(k, mode):
    cells = {q: [] for q in range(10)}
    for simplex in sorted(k):
        if 0 not in simplex:  # all genuine planar infinity is relative
            continue
        for cap, degree in CAP_DEG.items():
            if cap != 'd' and (mode == 'open' or (mode == 'deleted' and len(simplex) <= 2)):
                continue
            cells[len(simplex)-1+degree].append((simplex, cap))
    indexes = {q: {cell: j for j, cell in enumerate(cells[q])} for q in cells}
    d = {}
    for q in range(9):
        a = [[0]*len(cells[q]) for _ in cells[q+1]]
        for row, (simplex, cap) in enumerate(cells[q+1]):
            for j in range(len(simplex)):
                face = simplex[:j]+simplex[j+1:]
                col = indexes[q].get((face, cap))
                if col is not None:
                    a[row][col] += (-1)**j
            if cap == 'd':
                col = indexes[q].get((simplex, 't'))
                if col is not None:
                    a[row][col] += (-1)**(len(simplex)-1)
        d[q] = a
    for q in range(8):
        for row in range(len(cells[q+2])):
            for col in range(len(cells[q])):
                assert sum(d[q+1][row][j]*d[q][j][col] for j in range(len(cells[q+1]))) == 0
    ranks = {q: rank(d[q]) for q in d}
    groups = {q: len(cells[q])-ranks.get(q, 0)-ranks.get(q-1, 0) for q in cells}
    return {'cells': cells, 'd': d, 'groups': groups, 'ranks': ranks}


def restriction_audit(source, target):
    # Natural cochain restriction is the coordinate projection onto common cells.
    projections = {}
    for q in range(10):
        lookup = {c: j for j, c in enumerate(source['cells'][q])}
        projections[q] = [lookup[c] for c in target['cells'][q]]
    for q in range(9):
        for tr, sr in enumerate(projections[q+1]):
            for sc in range(len(source['cells'][q])):
                left = sum(target['d'][q][tr][j] for j, v in enumerate(projections[q]) if v == sc)
                assert left == source['d'][q][sr][sc]
    return True


def main():
    start = time.perf_counter()
    forms, collisions = collision_audit()
    rays = arrangement(forms)
    assert len(rays) == 12
    spaces = cover(rays)
    deleted = {name: complex_for(k, 'deleted') for name, k in spaces.items()}
    old = {name: complex_for(k, 'old') for name, k in spaces.items()}
    expected = {'0': {2: 8, 8: 8}, '1': {2: 8, 8: 8}, '2': {2: 8, 8: 8},
                '01': {2: 4, 8: 5}, '02': {2: 4, 8: 5}, '12': {2: 4, 8: 5}, '012': {8: 2}}
    counts = {}
    les_maps = {}
    for name, k in spaces.items():
        m = sum(0 in s and len(s) == 2 for s in k)
        n = sum(0 in s and len(s) == 3 for s in k)
        counts[name] = {'collision_rays': m, 'angular_cells': n}
        actual = {q: z for q, z in deleted[name]['groups'].items() if z}
        assert actual == expected[name]
        old_nonzero = {q: z for q, z in old[name]['groups'].items() if z}
        assert old_nonzero == ({} if len(name) == 1 else {1: len(name)-1})
        if len(name) == 2:
            radial = sorted(s for s in k if 0 in s and len(s) == 2)
            triangles = [s for s in k if 0 in s and len(s) == 3]
            isolated = [s for s in radial if not any(set(s) <= set(t) for t in triangles)]
            assert len(isolated) == 1
            idx = radial.index(isolated[0])
            vector = ([int(j == idx) for j in range(m-1)] if idx < m-1 else [-1]*(m-1))
            assert rank([[z] for z in vector]) == 1
            les_maps[name] = {'source_dimension': 1, 'target_dimension': m-1,
                              'ordered_ray_vertices': [s[1] for s in radial],
                              'isolated_ray_vertex': isolated[0][1], 'matrix': [[z] for z in vector]}
    les_maps['012'] = {'source_dimension': 2, 'target_dimension': 2, 'matrix': [[1, 0], [0, 1]]}
    natural_checks = 0
    for a, b in combinations(spaces, 2):
        if spaces[b] <= spaces[a]:
            restriction_audit(deleted[a], deleted[b])
            natural_checks += 1
        elif spaces[a] <= spaces[b]:
            restriction_audit(deleted[b], deleted[a])
            natural_checks += 1
    # Hostile controls must produce results different from the exact deletion.
    assert old['01']['groups'][1] == 1 != deleted['01']['groups'][1]
    opened = complex_for(spaces['0'], 'open')
    assert opened['groups'][2] == 0 != deleted['0']['groups'][2]
    opened_pair = complex_for(spaces['01'], 'open')
    assert opened_pair['groups'][8] == 1 != deleted['01']['groups'][8]
    moving_only = [z for z in collisions if z['rows'][0] >= 4]
    assert len(moving_only) == 3
    # At p=(0,1,-1), h=0 no moving pair collides; moving a0 is still -e2.
    assert len({0, 1, -1}) == 3
    assert any(z['rows'] == [1, 4] and z['condition']['linear_form'] == [1, 0] for z in collisions)
    output = {
        'verdict': 'PASS_FULL_DELETION_ABSTRACT_ONLY',
        'scope': 'Frozen seven-row surrogate only; original injectivity unresolved',
        'ledger': '2/9', 'original_obligations_closed': 0,
        'collision_linear_forms': forms, 'all_21_pair_conditions': collisions,
        'ordered_12_rays': rays, 'counts': counts,
        'deleted_compact_support_dimensions_degrees_0_through_9': {name: list(c['groups'].values()) for name, c in deleted.items()},
        'old_to_removed_Hc1_restriction_matrices': les_maps,
        'deleted_D': {'source_dimensions': [0, 0, 0], 'target_dimension': 0, 'matrix': [], 'kernel_dimension': 0},
        'required_lower_checks': {'singleton_Hc0': True, 'singleton_Hc1': True, 'singleton_Hc2': False, 'pair_Hc0': True, 'triple_Hc0': True},
        'natural_product_cochain_restrictions_checked': natural_checks,
        'hostile_controls_rejected': ['omit_coordinate_row_collisions', 'reuse_old_infinity_set', 'replace_partial_boundary_deletion_by_open_cap'],
        'max_relative_cells_in_any_deleted_space': max(sum(map(len, c['cells'].values())) for c in deleted.values()),
        'elapsed_seconds': round(time.perf_counter()-start, 6),
        'proof_boundary': 'Finite exact arithmetic plus written radial compactification and cellular product argument; not formal proof assistant verification.'
    }
    print(json.dumps(output, indent=2))


if __name__ == '__main__':
    main()
