# Independent opening audit

Base: `59fec66666518257c585194b81061f60d91f439d`. Read only the work order,
frozen `injectivity/falsifier/MODEL.json`, and the previous checkpoint's
`FINDINGS.md`; no current diagnostic producer output has been read.

## Full collision locus

Two moving rows can be proportional only with factor one, because their
second coordinate is -1. Comparing their last two coordinates forces h=0;
the remaining condition is equality of their p coordinates. This gives
u-v=0, 2u+v=0, u+2v=0. A moving row can be proportional to a basis row only
to e2, and this happens precisely when h=0 and its p coordinate is zero.
This adds u=0, v=0, u+v=0. Basis rows never collide. Thus the complete
deleted set is the union of these six lines, times the transverse S6.

## Independently derived answer before producer review

Subdivide the circle at the twelve oriented rays on those lines. A single
bad set has a link that is an eight-edge path with nine vertices. A pair
has a four-edge path together with one isolated vertex (six vertices in
total). The triple has three isolated vertices. Every such ray is in the
collision plane locus.

Deleting collisions removes each finite radial ray times S6, including the
finite origin times S6. The deleted closed subset of each old bad set is
a k-ray star times S6, with k=9,6,3. Its Hc0 is zero and Hc1 has dimension
k-1. Compact-support excision gives, in low degrees,

    0 -> Hc1(new) -> Hc1(old) -> Hc1(deleted)
      -> Hc2(new) -> Hc2(old)=0.

The middle map sends functions constant on connected components of the old
link to their values at all its vertices, modulo constants. It is injective
in each case: ranks 0,1,2 for single/pair/triple. Consequently all new Hc1
groups vanish; Hc2 dimensions are respectively 8,4,0. All new Hc0 vanish.
The new alternating pair-to-triple Hc1 map is therefore 0 -> 0.

My preliminary message to the coordinator suggested Hc1 might be preserved;
this was corrected immediately on completing the LES. That suggestion
omitted the restriction Hc1(old) -> Hc1(deleted) and is not a finding.

## Independent finite complex to be checked

Use K=cone(link) with true radial infinity the link. Model closed D7 by CW
cells q0,s6,t7 with boundary(t)=s. For the compactification pair, remove
link x D7 and cone(link vertices) x S6. After quotienting, the surviving
product cells are: all link-sector two-cells times q and s, and every
original relative cone cell times t. In degrees 0 and 1 there are no cells;
degree 2 has exactly the old link's edges, so the claimed low groups follow
directly without confusing ordinary and proper homotopy.

I will implement this product complex independently and compare with a
frozen producer result only afterward. No original injectivity claim or
ledger advancement follows; the required singleton Hc2 vanishing fails.
