# Replay the collision diagnostic

The bundle preserves sibling directories `collision_diagnostic/` and
`injectivity/`. The latter is the preceding frozen source checkpoint, not
a complete Git repository or a claim to contain every historical artifact.

From the extracted bundle root, with Python 3 and its standard library:

```sh
python -B collision_diagnostic/diagnostic/verify_deletion.py
python -B collision_diagnostic/referee/verify_independently.py
```

The second checker writes its deterministic `INDEPENDENT_RESULT.json` beside
itself. The first prints JSON; its `elapsed_seconds` field is observational
and must be excluded when comparing mathematical results. Neither checker
uses CUDA or installs dependencies. Keep `injectivity/falsifier/MODEL.json`
in its restored location for the independent source check.

Read `9DVL_Collision_Diagnostic_2026-09-09.md` for the accepted conclusion.
The immutable producer FINDINGS/HANDOFF retain their pre-review wording;
`referee/FINAL_REVIEW.md` and `CLOSING_STATE.json` record the final acceptance
boundary. Original injectivity remains open and the ledger remains 2/9.
