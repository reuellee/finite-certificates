# CUDA assessment for the collision diagnostic

9 September 2026. No CUDA program was run: this session exposes no NVIDIA
device. No RTX 2070 speedup has been measured. The CPU baseline in
`BASELINE_PROFILE.json` is one complete replay of the previous independent
countermodel checker, including interpreter startup and file hashing; it is
not a benchmark of a future large parent search.

The completed current diagnostic is recorded in `CLEAN_REPLAY.json`. Each
of its two independent checkers took about 0.03 seconds including Python
startup. The producer's internal computation took about 0.009 seconds in
that clean replay, with at most 34 surviving relative cells per space.
This is direct evidence that this particular exact replay is already small;
it is not a measured CPU-versus-GPU comparison.

The current experiment deletes an explicitly defined algebraic collision
locus and recomputes compact-support cohomology. It requires a correct
description of newly created ends and the restriction maps. Sampling alone
cannot certify these: exact collision sets can have measure zero. Its small
finite cochain calculations are not a demonstrated GPU bottleneck.

## Useful future CUDA tasks

| Candidate task | GPU work | Required evidence after discovery |
|---|---|---|
| Parent configuration screening | Evaluate all 70 four-brackets and the 56 derived normals for many 4-by-8 candidates in batches | Recheck accepted rational parents and signs exactly; preserve uncertain floating-point cases |
| Feasibility and circuit discovery | Batch row-vector products, separator margins, candidate short dependencies, and independent optimization starts | Exact primal inequalities or normalized nonnegative Gordan dependencies, plus original signature admission |
| Large integer cochain matrices, if they actually arise | Custom modular arithmetic and elimination across suitable primes or independent blocks | Certify the rational conclusion; a rank drop modulo one prime does not establish a rational kernel |

This is a proposed division of work, not an implemented CUDA backend or an
established performance result. A GPU can compute exact bounded integer and
modular arithmetic with correct overflow handling; it is not intrinsically
limited to approximate calculations. The existing Python rational checkers
do not automatically migrate to CUDA.

For an integral matrix, rank over a prime field is at most rank over Q. Full
column rank modulo a prime can therefore prove full column rank over Q;
modular rank deficiency alone cannot prove a Q-kernel. A candidate rational
kernel can be checked by exact multiplication. Rational matrices require
valid denominator clearing before this argument. GPU modular code would
need its own overflow and arithmetic verification boundary.

One illustrative FP64 data layout for 100,000 parent samples stores 32
coordinates, 70 bracket values, and 224 normal coordinates per sample:
260,800,000 bytes, about 249 MiB. This excludes solver state, temporary
arrays, duplicate buffers, and GPU framework overhead, and does not establish
a safe batch size or runtime. The user's 8 GB VRAM can accommodate such base
arrays, but actual working memory must be profiled.

## Recommended execution boundary

Keep this small diagnostic on CPU. If it identifies a justified large search,
profile a CPU implementation first, batch its independent arithmetic on the
laptop GPU, and feed discovered candidates into the exact CPU verifier.
Record timings including transfer and startup costs on the actual laptop.
Do not replace a required exhaustive coverage argument with GPU sampling.
For exhaustive work, a floating-point rejection must have a certified error
bound or be repeated exactly; a near-zero tolerance is not a proof of sign.

NVIDIA's [CUDA Best Practices Guide](https://docs.nvidia.com/cuda/cuda-c-best-practices-guide/index.html)
recommends profiling realistic workloads, exploiting substantial parallel
work, and minimizing host/device transfers by batching and retaining data on
the device. Its [floating-point guide](https://docs.nvidia.com/cuda/floating-point/index.html)
explains rounding and operation-order effects on both CPUs and GPUs. The
workload recommendations above are our application of those principles to
this project's exact certificate requirements.
