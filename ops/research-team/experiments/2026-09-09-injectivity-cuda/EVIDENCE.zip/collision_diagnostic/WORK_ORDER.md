# Collision-removal diagnostic, 2026-09-09

Base: frozen injectivity checkpoint at PR49 revision
`59fec66666518257c585194b81061f60d91f439d`.
Read-only inputs: `../injectivity/SOURCE_MANIFEST.json`,
`../injectivity/falsifier/MODEL.json`, `../injectivity/falsifier/FINDINGS.md`,
`../injectivity/referee/FINAL_REVIEW.md` and their exact checkers.
The original ledger is 2/9; original injectivity remains open.

Target: delete the complete locus on which any two distinct rows of the
seven-row abstract model are proportional. Compute the actual compact-support
restriction map for the remaining bad loci and recheck singleton Hc0,Hc1,Hc2,
pair Hc0, and triple Hc0. Determine whether the old kernel survives. Distinguish
failure of this deletion experiment from any universal no-parallel theorem.
Include new ends created by deletion; do not reuse the old compactification
unchanged, or silently replace the closed transverse ball by an open ball.

Roles: coordinator owns integration/CUDA assessment/checkpoint; diagnostic
worker owns `diagnostic/`; independent referee owns `referee/`. The referee
derives collision conditions independently before reading the frozen candidate.
No worker updates the original ledger, publishes, or changes pinned inputs.

Budget: one bounded experiment, at most 15 minutes per worker, no paid compute,
no GPU assumption, no broad saturation or search. Stop once this particular
deletion is resolved or an explicit unsolved computation is isolated. Produce
a useful negative/null outcome with exact remaining issue.

Deliverables: elementary proof with boundary/scope checks; standalone exact
replay if a finite complex is used; machine-readable dimensions/map and
appropriate hostile controls. Referee must not import producer acceptance
logic. Positive claim status requires independent review and clean replay.
No conclusion about original parent spaces without a proved comparison.
